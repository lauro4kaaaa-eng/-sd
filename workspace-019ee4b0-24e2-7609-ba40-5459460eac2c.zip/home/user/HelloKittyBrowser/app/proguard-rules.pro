# Hello Kitty Browser ProGuard rules
-keep class com.example.hellokitty.data.** { *; }
-keep class com.example.hellokitty.managers.** { *; }

# OkHttp
-dontwarn okhttp3.**
-dontwarn okio.**
-keep class okhttp3.** { *; }
-keep class okio.** { *; }

# kotlinx.serialization
-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.AnnotationsKt
-keepclassmembers class kotlinx.serialization.json.** { *** Companion; }
-keepclasseswithmembers class kotlinx.serialization.json.** { kotlinx.serialization.KSerializer serializer(...); }
-keep,includedescriptorclasses class com.example.hellokitty.**$$serializer { *; }
-keepclassmembers class com.example.hellokitty.** { *** Companion; }
-keepclasseswithmembers class com.example.hellokitty.** { kotlinx.serialization.KSerializer serializer(...); }