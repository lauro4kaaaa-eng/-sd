package com.example.hellokitty

import androidx.test.core.app.ActivityScenario
import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.action.ViewActions.*
import androidx.test.espresso.assertion.ViewAssertions.matches
import androidx.test.espresso.matcher.ViewMatchers.*
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.hamcrest.CoreMatchers.containsString
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class MainActivityEspressoTest {

    @Test
    fun addressBar_isVisible() {
        ActivityScenario.launch(MainActivity::class.java)
        onView(withId(R.id.et_address))
            .check(matches(isDisplayed()))
    }

    @Test
    fun navigationButtons_areVisible() {
        ActivityScenario.launch(MainActivity::class.java)
        onView(withId(R.id.btn_back)).check(matches(isDisplayed()))
        onView(withId(R.id.btn_forward)).check(matches(isDisplayed()))
        onView(withId(R.id.btn_refresh)).check(matches(isDisplayed()))
    }

    @Test
    fun menuButton_isVisible() {
        ActivityScenario.launch(MainActivity::class.java)
        onView(withId(R.id.btn_menu)).check(matches(isDisplayed()))
    }

    @Test
    fun typeUrl_inAddressBar() {
        ActivityScenario.launch(MainActivity::class.java)
        onView(withId(R.id.et_address))
            .perform(click(), clearText(), typeText("https://example.com"))
            .check(matches(withText(containsString("example.com"))))
    }

    @Test
    fun bookmarkToggle_isVisible() {
        ActivityScenario.launch(MainActivity::class.java)
        onView(withId(R.id.iv_bookmark_toggle))
            .check(matches(isDisplayed()))
    }
}