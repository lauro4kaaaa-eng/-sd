package com.example.hellokitty

import com.example.hellokitty.managers.NightModeManager
import org.junit.Assert.*
import org.junit.Test

class NightModeManagerTest {

    @Test
    fun initial_state_isDisabled() {
        assertFalse(NightModeManager.isNightMode)
    }

    @Test
    fun toggle_enablesNightMode() {
        NightModeManager.toggle(emptyList())
        assertTrue(NightModeManager.isNightMode)
    }

    @Test
    fun toggle_twice_disablesNightMode() {
        NightModeManager.toggle(emptyList())  // ON
        NightModeManager.toggle(emptyList())  // OFF
        assertFalse(NightModeManager.isNightMode)
    }

    @Test
    fun setEnabled_setsCorrectState() {
        NightModeManager.setEnabled(true, emptyList())
        assertTrue(NightModeManager.isNightMode)
        NightModeManager.setEnabled(false, emptyList())
        assertFalse(NightModeManager.isNightMode)
    }
}