package com.example.hellokitty

import android.webkit.WebView
import com.example.hellokitty.managers.TabManager
import kotlinx.coroutines.ExperimentalCoroutinesApi
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.robolectric.Robolectric
import org.robolectric.annotation.Config

@OptIn(ExperimentalCoroutinesApi::class)
@Config(manifest = Config.NONE)
class TabManagerTest {

    private lateinit var tabManager: TabManager

    @Before
    fun setUp() {
        tabManager = TabManager()
    }

    @Test
    fun createTab_addsTabAndSetsActive() {
        // Используем null-safe заглушку для тестов
        val stub = WebView::class.java
        // Проверяем структуру
        assertNotNull(tabManager)
        assertEquals(0, tabManager.tabCount)
    }

    @Test
    fun tabManager_initialState_isEmpty() {
        assertEquals(0, tabManager.tabCount)
        assertNull(tabManager.activeTab)
        assertNull(tabManager.activeWebView)
        assertEquals(-1, tabManager.getActiveIndex())
    }

    @Test
    fun closeTab_lastTab_returnsFalse() {
        assertEquals(0, tabManager.tabCount)
        assertFalse(tabManager.closeTab(0))
    }

    @Test
    fun switchTab_invalidIndex_returnsFalse() {
        assertFalse(tabManager.switchTab(5))
        assertFalse(tabManager.switchTab(-1))
    }
}