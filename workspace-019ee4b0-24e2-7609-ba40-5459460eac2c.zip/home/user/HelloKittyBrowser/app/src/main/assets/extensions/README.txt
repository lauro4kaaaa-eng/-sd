Hello Kitty Browser — Встроенные дополнения
==============================================

Поместите .xpi файлы дополнений в эту папку:

- ublock_origin.xpi — uBlock Origin Lite
- dark_reader.xpi   — Dark Reader

При сборке они автоматически копируются в APK и
устанавливаются через WebExtensionManager при запуске.

Поддерживаемые форматы: .xpi (Mozilla WebExtension)
