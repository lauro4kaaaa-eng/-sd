package com.example.hellokitty.managers

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKeys
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

/**
 * Менеджер синхронизации с Firefox Sync.
 * Хранит токен в зашифрованном SharedPreferences.
 * Начальный этап: закладки.
 */
object SyncManager {

    private const val PREFS_NAME = "firefox_sync_secure"
    private const val KEY_ACCESS_TOKEN = "fx_access_token"
    private const val KEY_REFRESH_TOKEN = "fx_refresh_token"
    private const val KEY_LOGGED_IN = "fx_logged_in"

    private const val FXA_URL = "https://accounts.firefox.com"
    private const val TOKEN_URL = "$FXA_URL/oauth/token"

    private var prefs: SharedPreferences? = null

    fun init(context: Context) {
        if (prefs == null) {
            val masterKey = MasterKeys.getOrCreate(MasterKeys.AES256_GCM_SPEC)
            prefs = EncryptedSharedPreferences.create(
                PREFS_NAME,
                masterKey,
                context.applicationContext,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        }
    }

    val isLoggedIn: Boolean
        get() = prefs?.getBoolean(KEY_LOGGED_IN, false) ?: false

    fun getAccessToken(): String? = prefs?.getString(KEY_ACCESS_TOKEN, null)

    /**
     * Сохраняет токен после успешной OAuth-авторизации.
     */
    fun saveTokens(accessToken: String, refreshToken: String) {
        prefs?.edit()
            ?.putString(KEY_ACCESS_TOKEN, accessToken)
            ?.putString(KEY_REFRESH_TOKEN, refreshToken)
            ?.putBoolean(KEY_LOGGED_IN, true)
            ?.apply()
    }

    /**
     * Выход из аккаунта — удаляет токены.
     */
    fun logout() {
        prefs?.edit()
            ?.remove(KEY_ACCESS_TOKEN)
            ?.remove(KEY_REFRESH_TOKEN)
            ?.putBoolean(KEY_LOGGED_IN, false)
            ?.apply()
    }

    /**
     * Синхронизация закладок с Firefox Sync.
     * В текущей версии — заглушка с полноценным HTTP-запросом.
     */
    suspend fun syncNow(
        onProgress: (String) -> Unit = {},
        onBookmarkReceived: (title: String, url: String) -> Unit = { _, _ -> }
    ): SyncResult = withContext(Dispatchers.IO) {
        try {
            onProgress("Подключение к Firefox Sync...")
            val token = getAccessToken()
            if (token == null) {
                return@withContext SyncResult.Failure("Не выполнен вход в аккаунт")
            }

            // Запрос к Firefox Sync Bookmarks Collection
            val url = URL("https://sync-1-us-west1-g.sync.services.mozilla.com/1.5/")
            val connection = url.openConnection() as HttpURLConnection
            connection.requestMethod = "GET"
            connection.setRequestProperty("Authorization", "Bearer $token")
            connection.setRequestProperty("Accept", "application/json")
            connection.connectTimeout = 15000
            connection.readTimeout = 15000

            val responseCode = connection.responseCode
            if (responseCode == 200) {
                val body = connection.inputStream.bufferedReader().readText()
                // Парсинг закладок из JSON
                val count = parseBookmarksFromSync(body, onBookmarkReceived)
                onProgress("Синхронизировано закладок: $count")
                SyncResult.Success(count)
            } else {
                SyncResult.Failure("Ошибка сервера: $responseCode")
            }
        } catch (e: Exception) {
            SyncResult.Failure("Сеть: ${e.message}")
        }
    }

    /**
     * Простой парсинг закладок из ответа Firefox Sync.
     * TODO: implement full JSON parsing with kotlinx.serialization for BSO format.
     */
    private fun parseBookmarksFromSync(
        json: String,
        onBookmark: (title: String, url: String) -> Unit
    ): Int {
        var count = 0
        // Простейший поиск URL и title в JSON
        val titleRegex = "\"title\"\\s*:\\s*\"([^\"]+)\"".toRegex()
        val urlRegex = "\"bmkUri\"\\s*:\\s*\"([^\"]+)\"".toRegex()
        val titles = titleRegex.findAll(json).map { it.groupValues[1] }.toList()
        val urls = urlRegex.findAll(json).map { it.groupValues[1] }.toList()

        titles.zip(urls).forEach { (title, url) ->
            onBookmark(title, url)
            count++
        }
        return count
    }

    sealed class SyncResult {
        data class Success(val count: Int) : SyncResult()
        data class Failure(val error: String) : SyncResult()
    }
}