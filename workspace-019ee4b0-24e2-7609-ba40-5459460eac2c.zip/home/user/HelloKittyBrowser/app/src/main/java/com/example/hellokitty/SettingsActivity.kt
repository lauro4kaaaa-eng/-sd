package com.example.hellokitty

import android.app.ProgressDialog
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Typeface
import android.os.Bundle
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebStorage
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.hellokitty.managers.SyncManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking

class SettingsActivity : AppCompatActivity() {

    private lateinit var rvSettings: RecyclerView
    private lateinit var viewModel: MainViewModel
    private var progressDialog: ProgressDialog? = null
    private lateinit var prefs: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        val appPrefs = applicationContext.getSharedPreferences("hellokitty_prefs", MODE_PRIVATE)
        when (appPrefs.getString("theme", "pink")) {
            "lavender" -> setTheme(R.style.Theme_HelloKitty_Lavender)
            "classic" -> setTheme(R.style.Theme_HelloKitty_Classic)
            else -> setTheme(R.style.Theme_HelloKittyBrowser)
        }
        super.onCreate(savedInstanceState)
        prefs = appPrefs
        setContentView(R.layout.activity_settings)

        val toolbar = findViewById<androidx.appcompat.widget.Toolbar>(R.id.toolbar_settings)
        toolbar.title = getString(R.string.settings_title)
        toolbar.setNavigationIcon(R.drawable.ic_back)
        toolbar.setNavigationOnClickListener { finish() }

        rvSettings = findViewById(R.id.rv_settings)
        viewModel = ViewModelProvider(this)[MainViewModel::class.java]

        rvSettings.layoutManager = LinearLayoutManager(this)
        rvSettings.adapter = SettingsAdapter()

        viewModel.chromeImportResult.observe(this) { result ->
            when (result) {
                is ChromeImportResult.InProgress -> {
                    progressDialog = ProgressDialog(this).apply {
                        setMessage(getString(R.string.importing)); setCancelable(false); show()
                    }
                }
                is ChromeImportResult.Success -> {
                    progressDialog?.dismiss()
                    Toast.makeText(this, getString(R.string.import_success, result.count), Toast.LENGTH_LONG).show()
                    viewModel.resetChromeImportResult()
                }
                is ChromeImportResult.Failure -> {
                    progressDialog?.dismiss()
                    Toast.makeText(this, getString(R.string.import_failed, result.message), Toast.LENGTH_LONG).show()
                    viewModel.resetChromeImportResult()
                }
                null -> {}
            }
        }
    }

    internal data class SettingItem(val icon: Int, val title: String, val subtitle: String? = null, val action: () -> Unit)
    internal data class Section(val title: String, val items: List<SettingItem>)

    inner class SettingsAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
        private val TYPE_HEADER = 0; private val TYPE_ITEM = 1

        private val sections = listOf(
            Section(getString(R.string.general), listOf(
                SettingItem(R.drawable.ic_settings, getString(R.string.search_engine), "Google / Bing / DuckDuckGo") { showSearchEngineDialog() },
                SettingItem(R.drawable.ic_download, getString(R.string.import_chrome_bookmarks), null) { viewModel.importChromeBookmarks() },
                SettingItem(R.drawable.ic_bookmark, getString(R.string.theme), getCurrentThemeLabel()) { showThemeDialog() }
            )),
            Section(getString(R.string.privacy), listOf(
                SettingItem(R.drawable.ic_history, getString(R.string.clear_history), null) { clearHistory() },
                SettingItem(R.drawable.ic_lock, getString(R.string.clear_cookies), null) { clearCookies() },
                SettingItem(R.drawable.ic_settings, getString(R.string.clear_cache), null) { clearCache() }
            )),
            Section("Firefox Sync", listOf(
                SettingItem(R.drawable.ic_share,
                    if (SyncManager.isLoggedIn) getString(R.string.firefox_logout) else getString(R.string.firefox_account),
                    if (SyncManager.isLoggedIn) "Выполнен вход" else "Синхронизация закладок") {
                    if (SyncManager.isLoggedIn) showLogoutDialog() else showFirefoxLogin()
                },
                SettingItem(R.drawable.ic_refresh, getString(R.string.sync_now), null) { doSyncNow() }
            )),
            Section(getString(R.string.about), listOf(
                SettingItem(R.drawable.ic_reader, getString(R.string.version_info), getString(R.string.about_description)) {}
            ))
        )

        private val flatItems = mutableListOf<Any>().apply { sections.forEach { add(it); addAll(it.items) } }
        override fun getItemViewType(p: Int) = if (flatItems[p] is Section) TYPE_HEADER else TYPE_ITEM
        override fun getItemCount() = flatItems.size

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            return if (viewType == TYPE_HEADER) {
                val tv = TextView(parent.context)
                tv.setPadding(48, 48, 48, 48)
                tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
                tv.setTextColor(android.graphics.Color.parseColor("#FF69B4"))
                tv.setTypeface(null, Typeface.BOLD)
                object : RecyclerView.ViewHolder(tv) {}
            } else {
                val view = LayoutInflater.from(parent.context).inflate(R.layout.item_bookmark, parent, false)
                SettingsViewHolder(view)
            }
        }

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, p: Int) {
            val item = flatItems[p]
            if (item is Section) (holder.itemView as? TextView)?.text = item.title
            else if (item is SettingItem) (holder as SettingsViewHolder).bind(item)
        }

        inner class SettingsViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
            private val tvTitle: TextView = itemView.findViewById(R.id.tv_bookmark_title)
            private val tvUrl: TextView = itemView.findViewById(R.id.tv_bookmark_url)
            private val ivIcon: ImageView = itemView.findViewById(R.id.iv_bookmark_icon)
            private val ivDelete: ImageView = itemView.findViewById(R.id.iv_delete_bookmark)

            internal fun bind(item: SettingItem) {
                tvTitle.text = item.title; tvUrl.text = item.subtitle ?: ""
                tvUrl.visibility = if (item.subtitle != null) View.VISIBLE else View.GONE
                ivIcon.setImageResource(item.icon); ivDelete.visibility = View.GONE
                itemView.setOnClickListener { item.action() }
            }
        }
    }

    private fun getCurrentThemeLabel() = when (prefs.getString("theme", "pink")) {
        "lavender" -> getString(R.string.theme_lavender); "classic" -> getString(R.string.theme_classic); else -> getString(R.string.theme_pink)
    }

    private fun showThemeDialog() {
        val themes = arrayOf(getString(R.string.theme_pink), getString(R.string.theme_lavender), getString(R.string.theme_classic))
        val cur = when (prefs.getString("theme", "pink")) { "lavender" -> 1; "classic" -> 2; else -> 0 }
        AlertDialog.Builder(this).setTitle(R.string.theme)
            .setSingleChoiceItems(themes, cur) { d, w ->
                prefs.edit().putString("theme", when (w) { 1 -> "lavender"; 2 -> "classic"; else -> "pink" }).apply()
                d.dismiss(); recreate()
            }.setNegativeButton(R.string.cancel, null).show()
    }

    private fun showSearchEngineDialog() {
        val engines = arrayOf("Google", "Bing", "DuckDuckGo")
        val cur = when (viewModel.searchEngine.value) { "bing" -> 1; "duckduckgo" -> 2; else -> 0 }
        AlertDialog.Builder(this).setTitle(R.string.search_engine)
            .setSingleChoiceItems(engines, cur) { d, w ->
                viewModel.searchEngine.value = when (w) { 1 -> "bing"; 2 -> "duckduckgo"; else -> "google" }; d.dismiss()
            }.setNegativeButton(R.string.cancel, null).show()
    }

    private fun clearHistory() {
        AlertDialog.Builder(this).setTitle(R.string.clear_history).setMessage("Удалить всю историю просмотров?")
            .setPositiveButton(R.string.ok) { _, _ -> viewModel.clearHistory(); Toast.makeText(this, "История очищена", Toast.LENGTH_SHORT).show() }
            .setNegativeButton(R.string.cancel, null).show()
    }

    private fun clearCookies() {
        CookieManager.getInstance().removeAllCookies(null)
        Toast.makeText(this, "Cookies очищены", Toast.LENGTH_SHORT).show()
    }

    private fun clearCache() {
        deleteDatabase("webview.db"); deleteDatabase("webviewCache.db"); WebStorage.getInstance().deleteAllData()
        Toast.makeText(this, "Кэш очищен", Toast.LENGTH_SHORT).show()
    }

    private fun showFirefoxLogin() {
        startActivity(Intent(this, MainActivity::class.java).apply { putExtra("firefox_login", true) })
    }

    private fun showLogoutDialog() {
        AlertDialog.Builder(this).setTitle(R.string.firefox_logout).setMessage("Выйти из Firefox Account?")
            .setPositiveButton(R.string.ok) { _, _ -> SyncManager.logout(); Toast.makeText(this, "Выполнен выход", Toast.LENGTH_SHORT).show(); rvSettings.adapter?.notifyDataSetChanged() }
            .setNegativeButton(R.string.cancel, null).show()
    }

    private fun doSyncNow() {
        if (!SyncManager.isLoggedIn) { Toast.makeText(this, "Сначала войдите в Firefox Account", Toast.LENGTH_SHORT).show(); return }
        GlobalScope.launch(Dispatchers.Main) {
            Toast.makeText(this@SettingsActivity, "Синхронизация...", Toast.LENGTH_SHORT).show()
            val result = SyncManager.syncNow(
                onProgress = { msg -> runOnUiThread { Toast.makeText(this@SettingsActivity, msg, Toast.LENGTH_SHORT).show() } },
                onBookmarkReceived = { title, url -> runBlocking { viewModel.addBookmark(title, url) } }
            )
            when (result) {
                is SyncManager.SyncResult.Success -> Toast.makeText(this@SettingsActivity, getString(R.string.sync_complete) + " (${result.count})", Toast.LENGTH_LONG).show()
                is SyncManager.SyncResult.Failure -> Toast.makeText(this@SettingsActivity, result.error, Toast.LENGTH_LONG).show()
            }
        }
    }
}
