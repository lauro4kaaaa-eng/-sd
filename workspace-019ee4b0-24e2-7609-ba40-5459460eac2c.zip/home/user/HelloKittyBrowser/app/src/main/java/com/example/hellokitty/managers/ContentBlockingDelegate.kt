package com.example.hellokitty.managers

/**
 * Упрощённая версия ContentBlockingDelegate для WebView.
 * WebView не имеет встроенного ContentBlocking API как GeckoView,
 * поэтому используется базовая реализация с подсчётом через WebViewClient.shouldInterceptRequest.
 */
class ContentBlockingDelegate {

    var onTrackerBlocked: ((Int) -> Unit)? = null
    var blockedTrackers: Int = 0
        private set
    private val blockedTrackerList = mutableListOf<String>()

    fun getBlockedTrackerList(): List<String> = blockedTrackerList.toList()

    fun reset() {
        blockedTrackers = 0
        blockedTrackerList.clear()
    }
}