package com.example.hellokitty.managers

import android.content.Context
import android.util.Log

/**
 * Менеджер WebExtensions (заглушка для WebView).
 * WebView не поддерживает WebExtensions API напрямую.
 * Расширения могут быть реализованы через JavaScript-инжекцию.
 */
object WebExtensionManager {

    private const val TAG = "WebExtensionManager"

    data class InstalledExtension(
        val id: String,
        val name: String,
        var enabled: Boolean
    )

    private val installedExtensions = mutableListOf<InstalledExtension>()

    fun installBuiltInExtensions(context: Context) {
        // В WebView расширения внедряются через JavaScript при загрузке страницы
        // Эта функция — заглушка для сохранения архитектуры
        Log.i(TAG, "WebView mode: extensions are JS-based, no .xpi installation needed")
    }

    fun getInstalledExtensions(): List<InstalledExtension> = installedExtensions.toList()

    fun toggleExtension(id: String): Boolean {
        val ext = installedExtensions.find { it.id == id } ?: return false
        ext.enabled = !ext.enabled
        return ext.enabled
    }
}