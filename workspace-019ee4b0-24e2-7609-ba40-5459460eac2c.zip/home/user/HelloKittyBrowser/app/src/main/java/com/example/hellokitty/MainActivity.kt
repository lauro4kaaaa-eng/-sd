package com.example.hellokitty

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Rect
import android.os.Bundle
import android.util.TypedValue
import android.view.*
import android.webkit.*
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.PopupMenu
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.example.hellokitty.managers.*
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.snackbar.Snackbar
import java.net.URLEncoder

class MainActivity : AppCompatActivity() {

    private lateinit var vm: MainViewModel
    private lateinit var tm: TabManager
    private lateinit var webBox: FrameLayout
    private lateinit var swipe: SwipeRefreshLayout
    private lateinit var etUrl: EditText
    private lateinit var ivLock: ImageView
    private lateinit var ivShield: ImageView
    private lateinit var ivBm: ImageView
    private lateinit var btnBack: ImageButton
    private lateinit var btnFwd: ImageButton
    private lateinit var btnRef: ImageButton
    private lateinit var btnHome: ImageButton
    private lateinit var btnTabs: ImageButton
    private lateinit var btnMenu: ImageButton
    private lateinit var btnAdd: ImageButton
    private lateinit var tvCnt: TextView
    private lateinit var rvSug: RecyclerView
    private lateinit var rvTabs: RecyclerView
    private lateinit var scrTabs: HorizontalScrollView
    private lateinit var findBar: LinearLayout
    private lateinit var etFind: EditText
    private lateinit var btnFp: Button
    private lateinit var btnFn: Button
    private lateinit var btnFd: Button
    private lateinit var prog: ProgressBar
    private lateinit var tabsAd: TabsAdapter
    private val sug = mutableListOf<String>()
    private var wv: WebView? = null
    private var curUrl = ""
    private var curTit = ""
    private var done = false
    private var blocked = 0

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_main)
        vm = ViewModelProvider(this)[MainViewModel::class.java]
        tm = vm.tabManager
        webBox = findViewById(R.id.gecko_container)
        swipe = findViewById(R.id.swipe_refresh)
        etUrl = findViewById(R.id.et_address)
        ivLock = findViewById(R.id.iv_lock)
        ivShield = findViewById(R.id.iv_shield)
        ivBm = findViewById(R.id.iv_bookmark_toggle)
        btnBack = findViewById(R.id.btn_back)
        btnFwd = findViewById(R.id.btn_forward)
        btnRef = findViewById(R.id.btn_refresh)
        btnHome = findViewById(R.id.btn_home)
        btnTabs = findViewById(R.id.btn_tabs_list)
        btnMenu = findViewById(R.id.btn_menu)
        btnAdd = findViewById(R.id.btn_new_tab)
        tvCnt = findViewById(R.id.tv_tab_count)
        rvSug = findViewById(R.id.rv_suggestions)
        rvTabs = findViewById(R.id.rv_tabs)
        scrTabs = findViewById(R.id.tabs_scroll)
        findBar = findViewById(R.id.find_bar)
        etFind = findViewById(R.id.et_find)
        btnFp = findViewById(R.id.btn_find_prev)
        btnFn = findViewById(R.id.btn_find_next)
        btnFd = findViewById(R.id.btn_find_done)
        prog = findViewById(R.id.progress_loading)
        swipe.setOnRefreshListener { wv?.reload() }
        swipe.setColorSchemeColors(getColor(R.color.pink_primary))
        initTabs()
        initFind()
        initObs()
        initSug()
        btnMenu.setOnClickListener { showMenu() }
        btnAdd.setOnClickListener { addTab(false) }
        btnHome.setOnClickListener { go("about:home") }
        if (!done) { addTab(false); go("about:home"); done = true }
        handleIntent(intent)
    }

    private fun addTab(priv: Boolean) {
        val w = WebView(this).apply {
            layoutParams = FrameLayout.LayoutParams(-1, -1)
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                setSupportZoom(true)
                builtInZoomControls = true
                displayZoomControls = false
                loadWithOverviewMode = true
                useWideViewPort = true
                textZoom = 100
            }
            webViewClient = Cli()
            webChromeClient = Chr()
            setDownloadListener { u, _, _, _, _ ->
                DownloadDelegate(this@MainActivity).startDownload(u, u.substringAfterLast('/'))
            }
            setOnLongClickListener { ctxMenu(it); true }
        }
        tm.createTab(w, priv)
        pickTab(tm.getActiveIndex())
        updTabs()
        showW(w)
    }

    private inner class Cli : WebViewClient() {
        override fun onPageStarted(v: WebView, u: String?, f: Bitmap?) {
            vm.setLoading(true)
            prog.visibility = View.VISIBLE
            prog.isIndeterminate = true
        }
        override fun onPageFinished(v: WebView, u: String?) {
            vm.setLoading(false)
            prog.visibility = View.GONE
            swipe.isRefreshing = false
            u?.let {
                curUrl = it
                vm.setUrl(it)
                vm.setSecure(it.startsWith("https://"))
                vm.checkBookmark(it)
                vm.addHistory(v.title ?: it, it)
                updTab(v, it)
                updAddr()
            }
        }
        override fun onReceivedError(v: WebView, r: WebResourceRequest, e: WebResourceError) {
            if (r.isForMainFrame) {
                vm.setLoading(false)
                prog.visibility = View.GONE
                swipe.isRefreshing = false
                errPg(v, e.errorCode, e.description.toString())
            }
        }
        override fun doUpdateVisitedHistory(v: WebView, u: String, rel: Boolean) {
            curUrl = u
            vm.setSecure(u.startsWith("https://"))
            updTab(v, u)
            updAddr()
        }
    }

    private inner class Chr : WebChromeClient() {
        override fun onReceivedTitle(v: WebView, t: String) {
            curTit = t; vm.setTitle(t); updTab(v, v.url ?: "")
        }
        override fun onProgressChanged(v: WebView, p: Int) {
            if (p < 100) { prog.isIndeterminate = false; prog.progress = p }
            else prog.visibility = View.GONE
        }
    }

    private fun errPg(v: WebView, code: Int, desc: String) {
        v.loadDataWithBaseURL(null, "<!DOCTYPE html><html><head><meta charset=utf-8><meta name=viewport content='width=device-width,initial-scale=1'><style>*{margin:0;padding:0;box-sizing:border-box}body{font-family:sans-serif;display:flex;flex-direction:column;align-items:center;justify-content:center;min-height:100vh;background:linear-gradient(180deg,#FFF0F7,#FFD6EC);color:#333;text-align:center;padding:20px}h1{font-size:20px;color:#FF69B4;margin:16px 0 8px}p{font-size:14px;color:#666;margin-bottom:20px}button{background:#FF69B4;color:#fff;border:none;padding:12px 28px;border-radius:20px;font-size:15px}</style></head><body><div style=font-size:56px>😿</div><h1>$desc</h1><p>Код: $code</p><button onclick=location.reload()>Повторить</button></body></html>", "text/html", "UTF-8", null)
    }

    private fun updTab(v: WebView, u: String) {
        val i = tm.allTabs.indexOfFirst { it.webView == v }
        if (i >= 0) { tm.updateTabUrl(i, u); tm.updateTabTitle(i, v.title ?: "") }
    }

    private fun pickTab(i: Int) {
        if (tm.switchTab(i)) {
            vm.activeTabIndex = i
            tm.getTab(i)?.let { wv = it.webView; curUrl = it.url; curTit = it.title; showW(it.webView); updAddr(); tabsAd.notifyDataSetChanged() }
        }
    }

    private fun showW(w: WebView) { webBox.removeAllViews(); webBox.addView(w); wv = w }
    private fun updAddr() { etUrl.setText(curUrl); ivLock.visibility = if (vm.isSecure.value == true) View.VISIBLE else View.GONE }
    private fun updSh(c: Int) { ivShield.visibility = if (c > 0) View.VISIBLE else View.GONE; blocked = c }

    private fun initTabs() {
        rvTabs.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        tabsAd = TabsAdapter(tm, { pickTab(it) }, { shutTab(it) })
        rvTabs.adapter = tabsAd
        tvCnt.setOnClickListener { tabSheet() }
        btnTabs.setOnClickListener { tabSheet() }
    }

    private fun updTabs() {
        scrTabs.visibility = if (tm.tabCount > 1) View.VISIBLE else View.GONE
        tvCnt.text = tm.tabCount.toString()
        tabsAd.notifyDataSetChanged()
    }

    private fun shutTab(i: Int) {
        if (tm.tabCount <= 1) { t("Нельзя закрыть последнюю") }
        else { tm.closeTab(i); updTabs(); pickTab(tm.getActiveIndex()) }
    }

    private fun tabSheet() {
        val d = BottomSheetDialog(this, R.style.BottomSheetTheme)
        val g = RecyclerView(this).apply {
            layoutManager = GridLayoutManager(this@MainActivity, 3)
            adapter = object : RecyclerView.Adapter<Tile>() {
                override fun onCreateViewHolder(p: ViewGroup, t: Int) = Tile(LayoutInflater.from(p.context).inflate(R.layout.item_tab_tile, p, false))
                override fun onBindViewHolder(h: Tile, pos: Int) { h.bind(tm.getTab(pos), pos) }
                override fun getItemCount() = tm.tabCount
            }
            addItemDecoration(object : RecyclerView.ItemDecoration() {
                override fun getItemOffsets(o: Rect, v: View, p: RecyclerView, s: RecyclerView.State) { o.set(12, 12, 12, 12) }
            })
        }
        d.setContentView(g)
        d.show()
    }

    private inner class Tile(v: View) : RecyclerView.ViewHolder(v) {
        private val tv: TextView = v.findViewById(R.id.tv_tile_title)
        private val iv: ImageView = v.findViewById(R.id.iv_tile_close)
        fun bind(t: TabManager.Tab?, p: Int) {
            if (t == null) return
            tv.text = t.title.ifEmpty { t.url.ifEmpty { "Новая" } }
            v.setBackgroundColor(if (p == tm.getActiveIndex()) getColor(R.color.pink_light) else getColor(R.color.gray_light))
            v.setOnClickListener { pickTab(p); (v.parent as? ViewGroup)?.parent?.let { (it as? View)?.parent?.let { q -> (q as? BottomSheetDialog)?.dismiss() } } }
            iv.setOnClickListener { shutTab(p); rvTabs.adapter?.notifyDataSetChanged() }
        }
    }

    private fun initFind() {
        btnFp.setOnClickListener { wv?.findNext(false) }
        btnFn.setOnClickListener { wv?.findNext(true) }
        btnFd.setOnClickListener { wv?.clearMatches(); findBar.visibility = View.GONE }
        etFind.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {
                s?.toString()?.let { if (it.isNotBlank()) wv?.findAllAsync(it) else wv?.clearMatches() }
            }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
    }

    private fun initObs() {
        vm.isBookmarked.observe(this) { ivBm.alpha = if (it) 1.0f else 0.35f }
        vm.blockedTrackerCount.observe(this) { updSh(it) }
        vm.isLoading.observe(this) { prog.visibility = if (it) View.VISIBLE else View.GONE }
        ivBm.setOnClickListener {
            if (vm.isBookmarked.value == true) { vm.removeBookmark(curUrl); t(getString(R.string.remove_bookmark)) }
            else { vm.addBookmark(curTit.ifEmpty { curUrl }, curUrl); t(getString(R.string.add_bookmark)) }
        }
        ivShield.setOnClickListener { trackSheet() }
        etUrl.setOnEditorActionListener { _, a, _ ->
            if (a == android.view.inputmethod.EditorInfo.IME_ACTION_GO) { go(etUrl.text.toString().trim()); rvSug.visibility = View.GONE; true } else false
        }
        btnBack.setOnClickListener { wv?.goBack() }
        btnFwd.setOnClickListener { wv?.goForward() }
        btnRef.setOnClickListener { if (vm.isLoading.value == true) wv?.stopLoading() else wv?.reload() }
    }

    private fun initSug() {
        etUrl.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) { vm.fetchSuggestions(s?.toString()?.trim() ?: "") }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
        rvSug.layoutManager = LinearLayoutManager(this)
        rvSug.adapter = object : RecyclerView.Adapter<SVH>() {
            override fun onCreateViewHolder(p: ViewGroup, t: Int): SVH {
                val tv = TextView(p.context)
                tv.setPadding(48, 40, 48, 40)
                tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                tv.setTextColor(getColor(R.color.text_primary))
                return SVH(tv)
            }
            override fun onBindViewHolder(h: SVH, pos: Int) {
                h.tv.text = sug.getOrNull(pos) ?: return
                h.tv.setOnClickListener { go(sug[pos]); rvSug.visibility = View.GONE }
            }
            override fun getItemCount() = sug.size
        }
        vm.suggestions.observe(this) { r ->
            sug.clear()
            when (r) {
                is SuggestResult.Empty -> rvSug.visibility = View.GONE
                is SuggestResult.Loading -> {}
                is SuggestResult.Success -> { sug.addAll(r.items); rvSug.visibility = if (r.items.isNotEmpty()) View.VISIBLE else View.GONE }
                is SuggestResult.Error -> { sug.add(getString(R.string.no_network)); rvSug.visibility = View.VISIBLE }
            }
            rvSug.adapter?.notifyDataSetChanged()
        }
    }

    private inner class SVH(val tv: TextView) : RecyclerView.ViewHolder(tv)

    private fun snack(msg: String, retry: Boolean = false) {
        val s = Snackbar.make(webBox, msg, Snackbar.LENGTH_LONG)
        if (retry && curUrl.isNotBlank()) s.setAction(R.string.retry) { wv?.reload() }
        s.show()
    }

    private fun ctxMenu(v: View) {
        val hit = (v as? WebView)?.hitTestResult?.extra ?: return
        AlertDialog.Builder(this).setTitle(hit).setItems(arrayOf("В новой вкладке", "Поделиться", "Копировать URL")) { _, w ->
            when (w) {
                0 -> { addTab(false); go(hit) }
                1 -> startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, hit) }, getString(R.string.share)))
                2 -> { (getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager).setPrimaryClip(android.content.ClipData.newPlainText("URL", hit)); t("Скопировано") }
            }
        }.show()
    }

    private fun showMenu() {
        val p = PopupMenu(this, btnMenu)
        p.menuInflater.inflate(R.menu.browser_menu, p.menu)
        p.menu.findItem(R.id.action_night_mode).isChecked = NightModeManager.isNightMode
        p.setOnMenuItemClickListener { i ->
            when (i.itemId) {
                R.id.action_new_tab -> { addTab(false); true }
                R.id.action_private_tab -> { addTab(true); true }
                R.id.action_bookmarks -> { frag(BookmarksFragment()); true }
                R.id.action_history -> { frag(HistoryFragment()); true }
                R.id.action_downloads -> { startActivity(Intent(android.app.DownloadManager.ACTION_VIEW_DOWNLOADS)); true }
                R.id.action_settings -> { startActivity(Intent(this, SettingsActivity::class.java)); true }
                R.id.action_find_in_page -> { findBar.visibility = View.VISIBLE; etFind.requestFocus(); true }
                R.id.action_reader_mode -> { wv?.let { ReaderModeManager.toggle(it); t(if (ReaderModeManager.isActive) "Чтение ON" else "Чтение OFF") }; true }
                R.id.action_night_mode -> { val on = NightModeManager.toggleWebViews(tm.allTabs.map { it.webView }); t(if (on) "Ночь ON" else "Ночь OFF"); true }
                R.id.action_share -> { if (curUrl.isNotBlank()) startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, curUrl) }, getString(R.string.share))); true }
                R.id.action_desktop_mode -> {
                    wv?.let {
                        val dUA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36"
                        val mUA = "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 Chrome/120.0.0.0 Mobile Safari/537.36"
                        it.settings.userAgentString = if (it.settings.userAgentString == dUA) mUA else dUA
                        t(if (it.settings.userAgentString == mUA) "Мобильная" else "ПК")
                        it.reload()
                    }; true
                }
                else -> false
            }
        }
        p.show()
    }

    private fun frag(f: Fragment) { supportFragmentManager.beginTransaction().replace(R.id.gecko_container, f).addToBackStack(null).commit() }

    private fun trackSheet() {
        val d = BottomSheetDialog(this)
        val v = layoutInflater.inflate(R.layout.bottom_sheet_trackers, null)
        v.findViewById<TextView>(R.id.tv_tracker_info).text = if (blocked == 0) getString(R.string.no_trackers) else getString(R.string.trackers_blocked, blocked)
        d.setContentView(v)
        d.show()
    }

    private fun go(input: String) {
        var u = input.trim()
        if (u.isEmpty()) return
        if (!u.startsWith("http://") && !u.startsWith("https://") && u != "about:home") {
            u = if (u.contains('.') && !u.contains(' ') && !u.contains('\n')) "https://$u"
            else when (vm.searchEngine.value ?: "google") {
                "bing" -> "https://www.bing.com/search?q=${URLEncoder.encode(u, "UTF-8")}"
                "duckduckgo" -> "https://duckduckgo.com/?q=${URLEncoder.encode(u, "UTF-8")}"
                else -> "https://www.google.com/search?q=${URLEncoder.encode(u, "UTF-8")}"
            }
        }
        load(u)
    }

    private fun load(u: String) {
        if (u == "about:home") { wv?.loadUrl("file:///android_asset/about_home.html"); curUrl = "about:home"; etUrl.setText("") }
        else { curUrl = u; wv?.loadUrl(u); etUrl.setText(u) }
    }

    override fun onNewIntent(i: Intent?) { super.onNewIntent(i); i?.let { if (it.action == Intent.ACTION_VIEW) it.data?.toString()?.let { load(it) }; if (it.getBooleanExtra("firefox_login", false)) load("https://accounts.firefox.com/oauth/?client_id=hellokitty_browser") } }
    private fun handleIntent(i: Intent?) = onNewIntent(i)

    override fun onBackPressed() {
        if (supportFragmentManager.backStackEntryCount > 0) supportFragmentManager.popBackStack()
        else if (wv?.canGoBack() == true) wv?.goBack()
        else super.onBackPressed()
    }

    override fun onDestroy() { super.onDestroy(); tm.allTabs.forEach { it.webView.destroy() } }
    private fun t(msg: String) { Toast.makeText(this, msg, Toast.LENGTH_SHORT).show() }
}
