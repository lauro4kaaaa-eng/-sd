package com.example.hellokitty

import android.app.Application
import android.app.ProgressDialog
import android.content.ContentValues
import android.database.Cursor
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.viewModelScope
import com.example.hellokitty.data.Bookmark
import com.example.hellokitty.data.BookmarkRepository
import com.example.hellokitty.data.HistoryEntry
import com.example.hellokitty.data.SuggestApi
import com.example.hellokitty.managers.TabManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainViewModel(
    application: Application,
    private val savedStateHandle: SavedStateHandle
) : AndroidViewModel(application) {

    private val repository = BookmarkRepository(application)
    val tabManager = TabManager()

    // --- Сохранение состояния через SavedStateHandle ---
    companion object {
        private const val KEY_ACTIVE_TAB_INDEX = "active_tab_index"
        private const val KEY_CURRENT_URL = "current_url"
        private const val KEY_CURRENT_TITLE = "current_title"
    }

    var activeTabIndex: Int
        get() = savedStateHandle.get<Int>(KEY_ACTIVE_TAB_INDEX) ?: -1
        set(value) { savedStateHandle[KEY_ACTIVE_TAB_INDEX] = value }

    // LiveData для закладок и истории
    val bookmarks: LiveData<List<Bookmark>> = repository.allBookmarks
    val history: LiveData<List<HistoryEntry>> = repository.allHistory

    // Состояние UI
    private val _blockedTrackerCount = MutableLiveData(0)
    val blockedTrackerCount: LiveData<Int> = _blockedTrackerCount

    private val _isLoading = MutableLiveData(false)
    val isLoading: LiveData<Boolean> = _isLoading

    private val _currentUrl = MutableLiveData(
        savedStateHandle.get<String>(KEY_CURRENT_URL) ?: ""
    )
    val currentUrl: LiveData<String> = _currentUrl

    private val _currentTitle = MutableLiveData(
        savedStateHandle.get<String>(KEY_CURRENT_TITLE) ?: ""
    )
    val currentTitle: LiveData<String> = _currentTitle

    private val _isSecure = MutableLiveData(false)
    val isSecure: LiveData<Boolean> = _isSecure

    private val _isBookmarked = MutableLiveData(false)
    val isBookmarked: LiveData<Boolean> = _isBookmarked

    private val _suggestions = MutableLiveData<SuggestResult>(SuggestResult.Empty)
    val suggestions: LiveData<SuggestResult> = _suggestions

    private val _chromeImportResult = MutableLiveData<ChromeImportResult>()
    val chromeImportResult: LiveData<ChromeImportResult> = _chromeImportResult

    val searchEngine = MutableLiveData(
        savedStateHandle.get<String>("search_engine") ?: "google"
    )

    fun setUrl(url: String) {
        _currentUrl.value = url
        savedStateHandle[KEY_CURRENT_URL] = url
    }

    fun setTitle(title: String) {
        _currentTitle.value = title
        savedStateHandle[KEY_CURRENT_TITLE] = title
    }

    fun setSecure(secure: Boolean) { _isSecure.value = secure }
    fun setLoading(loading: Boolean) { _isLoading.value = loading }
    fun setBlockedTrackerCount(count: Int) { _blockedTrackerCount.value = count }

    // --- Поисковые подсказки через OkHttp ---
    fun fetchSuggestions(query: String) {
        if (query.length < 2) {
            _suggestions.value = SuggestResult.Empty
            return
        }
        viewModelScope.launch {
            _suggestions.value = SuggestResult.Loading
            try {
                val localSuggestions = withContext(Dispatchers.IO) {
                    val bookmarks = repository.getAllBookmarksList()
                        .filter { it.title.contains(query, true) || it.url.contains(query, true) }
                        .take(3)
                        .map { it.title }
                    val history = repository.getAllHistoryList()
                        .filter { it.title.contains(query, true) || it.url.contains(query, true) }
                        .take(3)
                        .map { it.title }
                    (bookmarks + history).distinct()
                }

                val googleResult = withContext(Dispatchers.IO) {
                    SuggestApi.fetchSuggestions(query)
                }

                val googleSuggestions = googleResult.getOrElse { emptyList() }

                if (googleResult.isFailure && localSuggestions.isEmpty()) {
                    _suggestions.value = SuggestResult.Error
                } else {
                    val all = (localSuggestions + googleSuggestions).distinct()
                    _suggestions.value = if (all.isEmpty()) SuggestResult.Empty
                    else SuggestResult.Success(all)
                }
            } catch (e: Exception) {
                _suggestions.value = SuggestResult.Error
            }
        }
    }

    // --- Закладки ---
    fun addBookmark(title: String, url: String) {
        viewModelScope.launch {
            repository.addBookmark(title, url)
            _isBookmarked.value = true
        }
    }

    fun removeBookmark(url: String) {
        viewModelScope.launch {
            repository.removeBookmarkByUrl(url)
            _isBookmarked.value = false
        }
    }

    fun checkBookmark(url: String) {
        viewModelScope.launch {
            _isBookmarked.value = repository.isBookmarked(url)
        }
    }

    // --- История ---
    fun addHistory(title: String, url: String) {
        viewModelScope.launch {
            repository.addHistoryEntry(title, url)
        }
    }

    fun clearHistory() {
        viewModelScope.launch {
            repository.clearHistory()
        }
    }

    // --- Импорт закладок из Chrome ---
    fun importChromeBookmarks() {
        viewModelScope.launch {
            _chromeImportResult.value = ChromeImportResult.InProgress
            try {
                val count = withContext(Dispatchers.IO) {
                    importFromChromeProvider()
                }
                _chromeImportResult.value = ChromeImportResult.Success(count)
            } catch (e: Exception) {
                _chromeImportResult.value = ChromeImportResult.Failure(
                    e.message ?: "Неизвестная ошибка"
                )
            }
        }
    }

    private fun importFromChromeProvider(): Int {
        val context = getApplication<Application>()
        val uri = Uri.parse("content://com.android.chrome.browser/bookmarks")
        var imported = 0

        try {
            val cursor: Cursor? = context.contentResolver.query(
                uri,
                arrayOf("title", "url"),
                null, null, null
            )

            cursor?.use { c ->
                val titleIdx = c.getColumnIndexOrThrow("title")
                val urlIdx = c.getColumnIndexOrThrow("url")
                while (c.moveToNext()) {
                    val title = c.getString(titleIdx) ?: ""
                    val url = c.getString(urlIdx) ?: ""
                    if (url.isNotBlank()) {
                        kotlinx.coroutines.runBlocking {
                            repository.addBookmark(title, url)
                        }
                        imported++
                    }
                }
            }
        } catch (e: SecurityException) {
            // Нет разрешения — Chrome не предоставил доступ
            throw IllegalStateException(
                "Нет доступа к закладкам Chrome. " +
                        "Убедитесь, что Chrome установлен и разрешает доступ."
            )
        }
        return imported
    }

    fun resetChromeImportResult() {
        _chromeImportResult.value = null
    }

    override fun onCleared() {
        super.onCleared()
        // Сохраняем searchEngine
        savedStateHandle["search_engine"] = searchEngine.value
    }
}

// --- Sealed classes для UI-состояний ---

sealed class SuggestResult {
    data object Empty : SuggestResult()
    data object Loading : SuggestResult()
    data class Success(val items: List<String>) : SuggestResult()
    data object Error : SuggestResult()
}

sealed class ChromeImportResult {
    data object InProgress : ChromeImportResult()
    data class Success(val count: Int) : ChromeImportResult()
    data class Failure(val message: String) : ChromeImportResult()
}