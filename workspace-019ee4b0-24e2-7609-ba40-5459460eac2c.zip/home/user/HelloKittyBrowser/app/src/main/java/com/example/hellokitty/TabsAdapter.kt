package com.example.hellokitty

import android.graphics.Typeface
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.example.hellokitty.managers.TabManager

class TabsAdapter(
    private val tabManager: TabManager,
    private val onTabClick: (Int) -> Unit,
    private val onTabClose: (Int) -> Unit
) : RecyclerView.Adapter<TabsAdapter.TabViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TabViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_tab, parent, false)
        return TabViewHolder(view)
    }

    override fun onBindViewHolder(holder: TabViewHolder, position: Int) {
        holder.bind(tabManager.getTab(position), position)
    }

    override fun getItemCount(): Int = tabManager.tabCount

    inner class TabViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tvTitle: TextView = itemView.findViewById(R.id.tv_tab_title)
        private val ivClose: ImageView = itemView.findViewById(R.id.iv_close_tab)

        fun bind(tab: TabManager.Tab?, position: Int) {
            if (tab == null) return
            tvTitle.text = tab.title.ifEmpty { tab.url.ifEmpty { "Новая" } }
            tvTitle.setTypeface(null, Typeface.BOLD)
            val isActive = (position == tabManager.getActiveIndex())
            if (isActive) {
                itemView.setBackgroundColor(ContextCompat.getColor(itemView.context, R.color.pink_light))
                tvTitle.setTextColor(ContextCompat.getColor(itemView.context, R.color.hot_pink))
            } else if (tab.isPrivate) {
                itemView.setBackgroundColor(ContextCompat.getColor(itemView.context, R.color.purple_private))
                tvTitle.setTextColor(ContextCompat.getColor(itemView.context, R.color.white))
            } else {
                itemView.setBackgroundColor(ContextCompat.getColor(itemView.context, R.color.gray_light))
                tvTitle.setTextColor(ContextCompat.getColor(itemView.context, R.color.text_primary))
            }

            itemView.setOnClickListener { onTabClick(position) }
            ivClose.setOnClickListener { onTabClose(position) }
        }
    }
}