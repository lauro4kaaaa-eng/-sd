package com.example.hellokitty

import android.app.Application
import com.example.hellokitty.managers.SyncManager
import com.example.hellokitty.managers.WebExtensionManager

class HelloKittyApplication : Application() {

    override fun onCreate() {
        super.onCreate()

        // Инициализация шифрованных настроек для Firefox Sync
        SyncManager.init(this)

        // WebExtensionManager (заглушка для WebView)
        WebExtensionManager.installBuiltInExtensions(this)
    }
}