package com.example.hellokitty

import android.graphics.Typeface
import android.os.Bundle
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.hellokitty.data.HistoryEntry
import java.text.SimpleDateFormat
import java.util.*

class HistoryFragment : Fragment() {

    private var rvHistory: RecyclerView? = null
    private var tvEmpty: TextView? = null
    private var searchView: SearchView? = null
    private var viewModel: MainViewModel? = null
    private var allEntries = listOf<HistoryEntry>()

    private val dateFormat = SimpleDateFormat("dd MMMM yyyy", Locale("ru"))
    private val adapter = HistoryAdapter(onItemClick = { entry -> openHistoryEntry(entry) })

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_history, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        rvHistory = view.findViewById(R.id.rv_history); tvEmpty = view.findViewById(R.id.tv_empty_history); searchView = view.findViewById(R.id.search_history)
        rvHistory?.layoutManager = LinearLayoutManager(requireContext()); rvHistory?.adapter = adapter
        viewModel = ViewModelProvider(requireActivity())[MainViewModel::class.java]

        viewModel?.history?.observe(viewLifecycleOwner) { history -> allEntries = history; updateAdapter(history); tvEmpty?.visibility = if (history.isEmpty()) View.VISIBLE else View.GONE }

        searchView?.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean { query?.let { filterHistory(it) }; return true }
            override fun onQueryTextChange(newText: String?): Boolean { newText?.let { filterHistory(it) }; return true }
        })
    }

    private fun filterHistory(query: String) { updateAdapter(if (query.isBlank()) allEntries else allEntries.filter { it.title.contains(query, true) || it.url.contains(query, true) }) }

    private fun updateAdapter(entries: List<HistoryEntry>) {
        val grouped = entries.groupBy { dateFormat.format(Date(it.timestamp)) }
        val displayList = mutableListOf<Any>()
        grouped.forEach { (date, items) -> displayList.add(date); displayList.addAll(items) }
        adapter.submitList(displayList)
    }

    private fun openHistoryEntry(entry: HistoryEntry) { viewModel?.setUrl(entry.url); activity?.supportFragmentManager?.popBackStack() }

    inner class HistoryAdapter(private val onItemClick: (HistoryEntry) -> Unit) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
        private val VIEW_TYPE_HEADER = 0; private val VIEW_TYPE_ITEM = 1
        private var items = listOf<Any>()

        fun submitList(list: List<Any>) { items = list; notifyDataSetChanged() }
        override fun getItemViewType(position: Int): Int = if (items[position] is String) VIEW_TYPE_HEADER else VIEW_TYPE_ITEM
        override fun getItemCount(): Int = items.size

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            return if (viewType == VIEW_TYPE_HEADER) {
                val tv = TextView(parent.context)
                tv.setPadding(36, 36, 36, 36)
                tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                tv.setTextColor(android.graphics.Color.parseColor("#FF69B4"))
                tv.setTypeface(null, Typeface.BOLD)
                object : RecyclerView.ViewHolder(tv) {}
            } else {
                val view = LayoutInflater.from(parent.context).inflate(R.layout.item_history, parent, false)
                HistoryViewHolder(view)
            }
        }

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
            val item = items[position]
            if (item is String) (holder.itemView as? TextView)?.text = item
            else if (item is HistoryEntry) (holder as HistoryViewHolder).bind(item)
        }

        inner class HistoryViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
            private val tvTitle: TextView = itemView.findViewById(R.id.tv_history_title)
            private val tvUrl: TextView = itemView.findViewById(R.id.tv_history_url)

            fun bind(entry: HistoryEntry) { tvTitle.text = entry.title.ifEmpty { entry.url }; tvUrl.text = entry.url; itemView.setOnClickListener { onItemClick(entry) } }
        }
    }
}
