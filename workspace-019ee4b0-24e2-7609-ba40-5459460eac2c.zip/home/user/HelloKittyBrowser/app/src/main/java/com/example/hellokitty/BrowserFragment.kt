package com.example.hellokitty

import android.os.Bundle
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.webkit.*
import android.widget.*
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.snackbar.Snackbar
import java.net.URLEncoder

class BrowserFragment : Fragment() {

    private var webView: WebView? = null
    private var etAddress: EditText? = null
    private var ivLock: ImageView? = null
    private var ivShield: ImageView? = null
    private var ivBookmarkToggle: ImageView? = null
    private var rvSuggestions: RecyclerView? = null
    private var btnBack: ImageButton? = null
    private var btnForward: ImageButton? = null
    private var btnRefresh: ImageButton? = null
    private var progressBar: ProgressBar? = null

    private var viewModel: MainViewModel? = null
    private val suggestionItems = mutableListOf<String>()

    var currentUrl = ""; private set
    var currentTitle = ""; private set

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, state: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_browser, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel = ViewModelProvider(requireActivity())[MainViewModel::class.java]

        webView = WebView(requireContext()).apply {
            layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webViewClient = object : WebViewClient() {
                override fun onPageStarted(v: WebView, url: String?, favicon: android.graphics.Bitmap?) {
                    viewModel?.setLoading(true)
                    activity?.runOnUiThread { progressBar?.visibility = View.VISIBLE }
                }
                override fun onPageFinished(v: WebView, url: String?) {
                    viewModel?.setLoading(false)
                    activity?.runOnUiThread { progressBar?.visibility = View.GONE }
                    url?.let {
                        currentUrl = it; currentTitle = v.title ?: it
                        viewModel?.setUrl(it); viewModel?.setSecure(it.startsWith("https://"))
                        viewModel?.checkBookmark(it)
                        activity?.runOnUiThread { etAddress?.setText(it); updateSecurityIcons() }
                    }
                }
                override fun onReceivedError(v: WebView, r: WebResourceRequest, e: WebResourceError) {
                    activity?.runOnUiThread {
                        progressBar?.visibility = View.GONE
                        Snackbar.make(view, "Ошибка загрузки", Snackbar.LENGTH_LONG).setAction(R.string.retry) { v.reload() }.show()
                    }
                }
            }
        }
        view.findViewById<FrameLayout>(R.id.gecko_container_content)?.addView(webView)

        etAddress = view.findViewById(R.id.et_address); ivLock = view.findViewById(R.id.iv_lock)
        ivShield = view.findViewById(R.id.iv_shield); ivBookmarkToggle = view.findViewById(R.id.iv_bookmark_toggle)
        rvSuggestions = view.findViewById(R.id.rv_suggestions)
        btnBack = view.findViewById(R.id.btn_back); btnForward = view.findViewById(R.id.btn_forward)
        btnRefresh = view.findViewById(R.id.btn_refresh); progressBar = view.findViewById(R.id.progress_loading)

        setupAddressBar(); setupNavigationButtons(); setupObservers()
    }

    private fun setupAddressBar() {
        etAddress?.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO) { navigateTo(etAddress?.text.toString().trim()); rvSuggestions?.visibility = View.GONE; true } else false
        }
        rvSuggestions?.layoutManager = LinearLayoutManager(requireContext())
        rvSuggestions?.adapter = object : RecyclerView.Adapter<SuggestionVH>() {
            override fun onCreateViewHolder(p: ViewGroup, t: Int): SuggestionVH {
                val tv = TextView(p.context)
                tv.setPadding(48, 36, 48, 36)
                tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
                tv.setTextColor(ContextCompat.getColor(p.context, R.color.text_primary))
                return SuggestionVH(tv)
            }
            override fun onBindViewHolder(h: SuggestionVH, pos: Int) {
                h.tv.text = suggestionItems.getOrNull(pos)
                h.tv.setOnClickListener { navigateTo(suggestionItems[pos]); rvSuggestions?.visibility = View.GONE }
            }
            override fun getItemCount(): Int = suggestionItems.size
        }
        ivBookmarkToggle?.setOnClickListener {
            if (viewModel?.isBookmarked?.value == true) viewModel?.removeBookmark(currentUrl) else viewModel?.addBookmark(currentTitle, currentUrl)
        }
    }

    private inner class SuggestionVH(val tv: TextView) : RecyclerView.ViewHolder(tv)

    private fun setupNavigationButtons() {
        btnBack?.setOnClickListener { webView?.goBack() }
        btnForward?.setOnClickListener { webView?.goForward() }
        btnRefresh?.setOnClickListener { if (viewModel?.isLoading?.value == true) webView?.stopLoading() else webView?.reload() }
    }

    private fun setupObservers() {
        viewModel?.isBookmarked?.observe(viewLifecycleOwner) { ivBookmarkToggle?.alpha = if (it) 1.0f else 0.4f }
        viewModel?.isSecure?.observe(viewLifecycleOwner) { updateSecurityIcons() }
        viewModel?.isLoading?.observe(viewLifecycleOwner) { progressBar?.visibility = if (it) View.VISIBLE else View.GONE }
    }

    private fun updateSecurityIcons() { ivLock?.visibility = if (viewModel?.isSecure?.value == true) View.VISIBLE else View.GONE }

    private fun navigateTo(input: String) {
        var url = input.trim(); if (url.isEmpty()) return
        if (!url.startsWith("http://") && !url.startsWith("https://")) {
            url = if (url.contains('.') && !url.contains(' ') && !url.contains('\n')) "https://$url"
            else "https://www.google.com/search?q=${URLEncoder.encode(url, "UTF-8")}"
        }
        currentUrl = url; webView?.loadUrl(url); etAddress?.setText(url)
    }

    fun loadUrl(url: String) { navigateTo(url) }
    override fun onDestroyView() { super.onDestroyView(); webView?.destroy() }
}
