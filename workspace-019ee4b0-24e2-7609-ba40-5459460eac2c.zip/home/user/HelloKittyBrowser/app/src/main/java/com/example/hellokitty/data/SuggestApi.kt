package com.example.hellokitty.data

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.OkHttpClient
import okhttp3.Request
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

/**
 * API для Google Suggest через OkHttp + kotlinx.serialization.
 * Кэширует результаты на 5 минут для снижения нагрузки на сеть.
 */
object SuggestApi {

    // Настраиваем JSON-парсер, игнорируем неизвестные ключи
    private val json = Json { ignoreUnknownKeys = true }

    // OkHttp-клиент с таймаутами
    private val client = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(5, TimeUnit.SECONDS)
        .build()

    // Кэш в памяти: query -> (timestamp, suggestions)
    private val cache = mutableMapOf<String, CacheEntry>()

    private data class CacheEntry(
        val timestamp: Long,
        val suggestions: List<String>
    )

    private const val CACHE_DURATION_MS = 5 * 60 * 1000L  // 5 минут

    /**
     * Возвращает подсказки из Google Suggest API.
     * При ошибке сети возвращает пустой список.
     */
    fun fetchSuggestions(query: String): Result<List<String>> {
        // Проверяем кэш
        val cached = cache[query.lowercase()]
        if (cached != null &&
            System.currentTimeMillis() - cached.timestamp < CACHE_DURATION_MS
        ) {
            return Result.success(cached.suggestions)
        }

        return try {
            val encoded = URLEncoder.encode(query, "UTF-8")
            val url = "https://suggestqueries.google.com/complete/search?client=firefox&q=$encoded"

            val request = Request.Builder()
                .url(url)
                .header("User-Agent", "Mozilla/5.0 HelloKittyBrowser/1.0")
                .build()

            val response = client.newCall(request).execute()
            val body = response.body?.string() ?: return Result.success(emptyList())

            val suggestions = parseSuggestResponse(body)
            // Сохраняем в кэш
            cache[query.lowercase()] = CacheEntry(
                timestamp = System.currentTimeMillis(),
                suggestions = suggestions
            )
            // Очищаем старые записи кэша, если их > 50
            if (cache.size > 50) {
                val expireTime = System.currentTimeMillis() - CACHE_DURATION_MS
                cache.entries.removeAll { it.value.timestamp < expireTime }
            }

            Result.success(suggestions)
        } catch (e: Exception) {
            // Сеть недоступна — возвращаем ошибку
            Result.failure(e)
        }
    }

    /**
     * Парсинг ответа Google Suggest.
     * Формат: ["query", ["suggestion1", "suggestion2", ...], [], [], {...}]
     */
    private fun parseSuggestResponse(responseText: String): List<String> {
        return try {
            val parsed = json.parseToJsonElement(responseText)
            if (parsed is JsonArray && parsed.size >= 2) {
                val suggestionsArray = parsed[1]
                if (suggestionsArray is JsonArray) {
                    suggestionsArray.mapNotNull { element ->
                        val text = element.jsonPrimitive.content
                        if (text.isNotBlank()) text else null
                    }
                } else emptyList()
            } else emptyList()
        } catch (e: Exception) {
            // Fallback-парсинг для нетипичных ответов
            parseSimpleFallback(responseText)
        }
    }

    private fun parseSimpleFallback(responseText: String): List<String> {
        val suggestions = mutableListOf<String>()
        val bracket1 = responseText.indexOf('[', responseText.indexOf('[') + 1)
        if (bracket1 > 0) {
            val bracketEnd = responseText.indexOf(']', bracket1)
            if (bracketEnd > bracket1) {
                responseText.substring(bracket1 + 1, bracketEnd).split(',')
                    .forEach { item ->
                        val cleaned = item.trim().removeSurrounding("\"")
                        if (cleaned.isNotBlank() && cleaned.length > 2)
                            suggestions.add(cleaned)
                    }
            }
        }
        return suggestions
    }

    /**
     * Очистка кэша (например, при очистке данных браузера).
     */
    fun clearCache() {
        cache.clear()
    }
}
