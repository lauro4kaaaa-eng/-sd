package com.example.hellokitty.managers

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment

/**
 * Перехватывает загрузки и передаёт их системному DownloadManager.
 */
class DownloadDelegate(private val context: Context) {

    private val downloadManager: DownloadManager =
        context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager

    var onDownloadStarted: ((String) -> Unit)? = null

    fun startDownload(url: String, filename: String) {
        try {
            downloadManager.enqueue(
                DownloadManager.Request(Uri.parse(url))
                    .setTitle(filename)
                    .setDescription(context.getString(com.example.hellokitty.R.string.download_started))
                    .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, filename)
                    .setAllowedOverMetered(true)
                    .setAllowedOverRoaming(true)
            )
            onDownloadStarted?.invoke(filename)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}