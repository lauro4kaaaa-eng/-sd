package com.example.hellokitty.data

import android.content.Context
import androidx.lifecycle.LiveData

class BookmarkRepository(context: Context) {

    private val db = BookmarkDatabase.getInstance(context)
    private val bookmarkDao = db.bookmarkDao()
    private val historyDao = db.historyDao()

    // --- Bookmarks ---

    val allBookmarks: LiveData<List<Bookmark>> = bookmarkDao.getAllBookmarks()

    suspend fun addBookmark(title: String, url: String) {
        val existing = bookmarkDao.getBookmarkByUrl(url)
        if (existing == null) {
            bookmarkDao.insert(Bookmark(title = title, url = url))
        }
    }

    suspend fun removeBookmarkByUrl(url: String) {
        bookmarkDao.deleteByUrl(url)
    }

    suspend fun isBookmarked(url: String): Boolean {
        return bookmarkDao.getBookmarkByUrl(url) != null
    }

    suspend fun getAllBookmarksList(): List<Bookmark> {
        return bookmarkDao.getAllBookmarksList()
    }

    // --- History ---

    val allHistory: LiveData<List<HistoryEntry>> = historyDao.getAllHistory()

    suspend fun addHistoryEntry(title: String, url: String) {
        // Удаляем старую запись с тем же URL, чтобы не дублировать
        historyDao.deleteByUrl(url)
        historyDao.insert(HistoryEntry(title = title, url = url))
    }

    suspend fun clearHistory() {
        historyDao.deleteAll()
    }

    suspend fun getAllHistoryList(): List<HistoryEntry> {
        return historyDao.getAllHistoryList()
    }

    suspend fun removeHistoryEntry(entry: HistoryEntry) {
        historyDao.delete(entry)
    }
}
