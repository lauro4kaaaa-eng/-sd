package com.example.hellokitty.managers

import android.webkit.WebView

/**
 * Менеджер вкладок: создание, переключение, закрытие, приватные вкладки.
 * Использует WebView вместо GeckoSession.
 */
class TabManager {

    data class Tab(
        val webView: WebView,
        var title: String = "",
        var url: String = "",
        val isPrivate: Boolean = false
    )

    private val tabs = mutableListOf<Tab>()
    private var activeIndex: Int = -1

    val activeTab: Tab?
        get() = tabs.getOrNull(activeIndex)

    val allTabs: List<Tab>
        get() = tabs.toList()

    val tabCount: Int
        get() = tabs.size

    val activeWebView: WebView?
        get() = activeTab?.webView

    fun getActiveIndex(): Int = activeIndex

    fun createTab(webView: WebView, isPrivate: Boolean = false): Int {
        val tab = Tab(webView = webView, isPrivate = isPrivate)
        tabs.add(tab)
        activeIndex = tabs.size - 1
        return activeIndex
    }

    fun switchTab(index: Int): Boolean {
        if (index in tabs.indices) {
            activeIndex = index
            return true
        }
        return false
    }

    fun closeTab(index: Int): Boolean {
        if (index in tabs.indices && tabs.size > 1) {
            val webView = tabs[index].webView
            webView.destroy()
            tabs.removeAt(index)
            if (activeIndex >= tabs.size) {
                activeIndex = tabs.size - 1
            } else if (activeIndex > index) {
                activeIndex--
            } else if (activeIndex == index) {
                activeIndex = index.coerceAtMost(tabs.size - 1)
            }
            return true
        }
        return false
    }

    fun updateTabTitle(index: Int, title: String) {
        tabs.getOrNull(index)?.title = title
    }

    fun updateTabUrl(index: Int, url: String) {
        tabs.getOrNull(index)?.url = url
    }

    fun getTab(index: Int): Tab? = tabs.getOrNull(index)
}