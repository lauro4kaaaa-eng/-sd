package com.example.hellokitty.managers

import android.webkit.WebView

/**
 * Режим чтения через JavaScript-инжекцию в WebView.
 */
object ReaderModeManager {

    private var readerModeActive = false

    val isActive: Boolean get() = readerModeActive

    private val readerJS = """
        javascript:(function(){
            var article=document.body.innerText;
            var h=document.querySelector('h1');
            var title=h?h.innerText:document.title;
            document.head.innerHTML='<meta name="viewport" content="width=device-width"><style>body{max-width:680px;margin:0 auto;padding:20px;font-family:Georgia,serif;font-size:18px;line-height:1.7;color:#333;background:#fafafa}img{max-width:100%}h1{font-size:28px;color:#FF69B4}a{color:#FF69B4}</style>';
            document.body.innerHTML='<h1>'+title+'</h1>'+article.replace(/\n/g,'<br>');
        })()
    """.trimIndent()

    fun enterReaderMode(view: WebView) {
        view.loadUrl(readerJS)
        readerModeActive = true
    }

    fun exitReaderMode(view: WebView) {
        readerModeActive = false
        view.reload()
    }

    fun toggle(view: WebView): Boolean {
        if (readerModeActive) exitReaderMode(view) else enterReaderMode(view)
        return readerModeActive
    }
}