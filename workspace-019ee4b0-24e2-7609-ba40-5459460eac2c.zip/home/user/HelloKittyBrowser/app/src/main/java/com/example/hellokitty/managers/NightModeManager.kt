package com.example.hellokitty.managers

import android.webkit.WebView

/**
 * Инжекция CSS для тёмной (ночной) темы во все активные WebView.
 */
object NightModeManager {

    private var nightModeEnabled = false

    private val darkCSS = """
        javascript:(function(){
            var s=document.createElement('style');
            s.id='hk-night';
            s.textContent='*{background-color:#1a1a1a!important;color:#e0e0e0!important;}a{color:#FF69B4!important}img,video,canvas{filter:brightness(0.8)}';
            document.head.appendChild(s);
        })()
    """.trimIndent()

    private val removeCSS = """
        javascript:(function(){
            var s=document.getElementById('hk-night');
            if(s)s.remove();
        })()
    """.trimIndent()

    val isNightMode: Boolean get() = nightModeEnabled

    fun toggleWebViews(views: List<WebView>): Boolean {
        nightModeEnabled = !nightModeEnabled
        applyToAll(views)
        return nightModeEnabled
    }

    fun toggle(views: List<WebView>): Boolean = toggleWebViews(views)

    fun setEnabled(enabled: Boolean, views: List<WebView>) {
        nightModeEnabled = enabled
        applyToAll(views)
    }

    fun applyToAll(views: List<WebView>) {
        val script = if (nightModeEnabled) darkCSS else removeCSS
        views.forEach { it.loadUrl(script) }
    }
}