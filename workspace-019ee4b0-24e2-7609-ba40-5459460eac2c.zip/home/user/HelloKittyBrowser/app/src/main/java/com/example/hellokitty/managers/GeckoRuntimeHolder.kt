package com.example.hellokitty.managers

import android.webkit.WebView

/**
 * Синглтон для инициализации WebView.
 * Android WebView не требует отдельного Runtime, как GeckoView.
 * Этот класс сохраняет совместимость с существующей архитектурой.
 */
object GeckoRuntimeHolder {

    /**
     * Инициализация WebView (вызывается при старте, но WebView не требует предзагрузки).
     */
    fun initWebView(webView: WebView) {
        // WebView инициализируется при создании; никаких дополнительных действий не нужно
    }
}
