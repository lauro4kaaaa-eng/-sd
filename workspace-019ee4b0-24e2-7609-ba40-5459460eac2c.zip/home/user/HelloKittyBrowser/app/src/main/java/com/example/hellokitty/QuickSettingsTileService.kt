package com.example.hellokitty

import android.graphics.drawable.Icon
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import androidx.annotation.RequiresApi
import com.example.hellokitty.managers.NightModeManager

/**
 * TileService для быстрых настроек — переключение ночного режима.
 */
@RequiresApi(Build.VERSION_CODES.N)
class QuickSettingsTileService : TileService() {

    override fun onStartListening() {
        super.onStartListening()
        updateTile()
    }

    override fun onClick() {
        super.onClick()
        // Переключаем глобальный флаг
        NightModeManager.setEnabled(!NightModeManager.isNightMode, emptyList())
        updateTile()
    }

    private fun updateTile() {
        qsTile?.apply {
            state = if (NightModeManager.isNightMode) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
            label = "Ночной режим"
            icon = Icon.createWithResource(this@QuickSettingsTileService, R.drawable.ic_shield)
            updateTile()
        }
    }
}