package com.example.hellokitty.managers

import android.webkit.WebView

/**
 * Поиск текста на странице через WebView.findAllAsync().
 */
class FindInPageManager {

    private var currentView: WebView? = null

    fun startSearch(view: WebView, query: String) {
        currentView = view
        view.findAllAsync(query)
    }

    fun findNext() {
        currentView?.findNext(true)
    }

    fun clear() {
        currentView?.clearMatches()
        currentView = null
    }
}