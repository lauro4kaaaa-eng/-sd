package com.example.hellokitty

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.hellokitty.data.Bookmark
import kotlinx.coroutines.launch

class BookmarksFragment : Fragment() {

    private var rvBookmarks: RecyclerView? = null
    private var tvEmpty: TextView? = null
    private var fabAdd: com.google.android.material.floatingactionbutton.FloatingActionButton? = null
    private var viewModel: MainViewModel? = null
    private val adapter = BookmarksAdapter(
        onItemClick = { bookmark -> openBookmark(bookmark) },
        onItemDelete = { bookmark -> deleteBookmark(bookmark) }
    )

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_bookmarks, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        rvBookmarks = view.findViewById(R.id.rv_bookmarks)
        tvEmpty = view.findViewById(R.id.tv_empty_bookmarks)
        fabAdd = view.findViewById(R.id.fab_add_bookmark)

        rvBookmarks?.layoutManager = LinearLayoutManager(requireContext())
        rvBookmarks?.adapter = adapter

        viewModel = ViewModelProvider(requireActivity())[MainViewModel::class.java]

        viewModel?.bookmarks?.observe(viewLifecycleOwner) { bookmarks ->
            adapter.submitList(bookmarks)
            tvEmpty?.visibility = if (bookmarks.isEmpty()) View.VISIBLE else View.GONE
        }

        fabAdd?.setOnClickListener {
            // Добавление текущей страницы в закладки
            val url = viewModel?.currentUrl?.value ?: ""
            val title = viewModel?.currentTitle?.value ?: ""
            if (url.isNotBlank()) {
                viewModel?.addBookmark(title, url)
                Toast.makeText(requireContext(), R.string.add_bookmark, Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun openBookmark(bookmark: Bookmark) {
        // Возвращаемся в браузер и загружаем URL
        viewModel?.setUrl(bookmark.url)
        activity?.supportFragmentManager?.popBackStack()
    }

    private fun deleteBookmark(bookmark: Bookmark) {
        lifecycleScope.launch {
            viewModel?.removeBookmark(bookmark.url)
        }
    }

    inner class BookmarksAdapter(
        private val onItemClick: (Bookmark) -> Unit,
        private val onItemDelete: (Bookmark) -> Unit
    ) : RecyclerView.Adapter<BookmarksAdapter.ViewHolder>() {

        private var items = listOf<Bookmark>()

        fun submitList(list: List<Bookmark>) {
            items = list
            notifyDataSetChanged()
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_bookmark, parent, false)
            return ViewHolder(view)
        }

        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            holder.bind(items[position])
        }

        override fun getItemCount(): Int = items.size

        inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
            private val tvTitle: TextView = itemView.findViewById(R.id.tv_bookmark_title)
            private val tvUrl: TextView = itemView.findViewById(R.id.tv_bookmark_url)
            private val ivDelete: ImageView = itemView.findViewById(R.id.iv_delete_bookmark)

            fun bind(bookmark: Bookmark) {
                tvTitle.text = bookmark.title.ifEmpty { bookmark.url }
                tvUrl.text = bookmark.url
                itemView.setOnClickListener { onItemClick(bookmark) }
                ivDelete.setOnClickListener { onItemDelete(bookmark) }
            }
        }
    }
}