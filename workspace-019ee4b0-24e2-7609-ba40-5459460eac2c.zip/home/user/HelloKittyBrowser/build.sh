#!/bin/bash
# ==============================================
# Hello Kitty Browser — сборка и запуск
# Скопируй HelloKittyBrowser/ в любое место
# и запусти этот скрипт из папки проекта
# ==============================================
set -e

PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$PROJECT_DIR"

echo "📁 Проект: $PROJECT_DIR"

# --- 1. Проверка JDK ---
echo ""
echo "=== Проверка JDK ==="
java -version 2>&1 | head -1
JAVA_VER=$(java -version 2>&1 | head -1 | grep -oP '\d+' | head -1 || echo "0")
if [ "$JAVA_VER" -lt 17 ]; then
  echo "❌ Нужен JDK 17+. Установи: sudo dnf install java-17-openjdk-devel"
  exit 1
fi
echo "✅ JDK $JAVA_VER — OK"

# --- 2. Проверка ANDROID_HOME ---
echo ""
echo "=== Проверка Android SDK ==="
if [ -z "$ANDROID_HOME" ]; then
  if [ -d "$HOME/Android/Sdk" ]; then
    export ANDROID_HOME="$HOME/Android/Sdk"
    echo "export ANDROID_HOME=\"\$HOME/Android/Sdk\"" >> ~/.bashrc
  else
    echo "❌ ANDROID_HOME не найден. Укажи путь к SDK:"
    echo "   export ANDROID_HOME=/путь/к/Android/Sdk"
    exit 1
  fi
fi
echo "✅ ANDROID_HOME=$ANDROID_HOME"

# Проверка платформы
if [ -d "$ANDROID_HOME/platforms/android-36" ]; then
  echo "✅ android-36 — OK"
else
  echo "⚠️  android-36 не найден. Устанавливаю..."
  yes | "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" "platforms;android-36" 2>/dev/null || {
    echo "❌ Не удалось установить. Установи вручную в Android Studio:"
    echo "   Settings → Languages & Frameworks → Android SDK → API 36"
    exit 1
  }
fi

# --- 3. Генерация Gradle Wrapper (если нет) ---
echo ""
echo "=== Gradle Wrapper ==="
if [ ! -f "gradlew" ]; then
  echo "Генерирую gradlew..."
  gradle wrapper --gradle-version 8.2 2>/dev/null || {
    # Если gradle не установлен — создаём wrapper вручную
    mkdir -p gradle/wrapper
    cat > gradle/wrapper/gradle-wrapper.properties << 'WRAPPER'
distributionBase=GRADLE_USER_HOME
distributionPath=wrapper/dists
distributionUrl=https\://services.gradle.org/distributions/gradle-8.2-bin.zip
networkTimeout=10000
validateDistributionUrl=true
zipStoreBase=GRADLE_USER_HOME
zipStorePath=wrapper/dists
WRAPPER
    # Скачиваем официальный gradle-wrapper.jar
    curl -sL "https://raw.githubusercontent.com/gradle/gradle/v8.2.0/gradle/wrapper/gradle-wrapper.jar" -o gradle/wrapper/gradle-wrapper.jar 2>/dev/null || {
      echo "⚠️  Не удалось скачать gradle-wrapper.jar. Установи Gradle:"
      echo "   sudo dnf install gradle"
      echo "   Затем: gradle wrapper --gradle-version 8.2"
      exit 1
    }
    # Копируем скрипт
    cat > gradlew << 'GRADLEW'
#!/bin/sh
# Gradle wrapper script
CLASSPATH=$APP_HOME/gradle/wrapper/gradle-wrapper.jar
exec java -classpath "$CLASSPATH" org.gradle.wrapper.GradleWrapperMain "$@"
GRADLEW
    chmod +x gradlew
  }
fi
echo "✅ gradlew готов"

# --- 4. Сборка ---
echo ""
echo "=== Сборка проекта ==="
echo "Это займёт 3–10 минут при первом запуске (скачивание зависимостей)..."
./gradlew assembleDebug --no-daemon 2>&1 | tail -20

if [ -f "app/build/outputs/apk/debug/app-debug.apk" ]; then
  echo ""
  echo "=========================================="
  echo "  ✅  СБОРКА УСПЕШНА!"
  echo "  APK: app/build/outputs/apk/debug/app-debug.apk"
  echo "=========================================="
  echo ""
  echo "Установи на устройство:"
  echo "  adb install app/build/outputs/apk/debug/app-debug.apk"
else
  echo ""
  echo "❌ Сборка не удалась. Открой проект в Android Studio:"
  echo "   File → Open → $PROJECT_DIR"
fi