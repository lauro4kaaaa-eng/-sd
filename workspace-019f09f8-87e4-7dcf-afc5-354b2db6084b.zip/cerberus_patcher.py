#!/usr/bin/env python3
"""
Cerberus v1.0 safe post-processing patcher.

This script performs defensive/safety-preserving normalization of the Cerberus
post-exploitation modules and config. It intentionally does NOT enable real
Metasploit exploitation, stealth collection, direct PoC execution, or removal of
safety controls. Instead it enforces the safe Red Team profile that is suitable
for controlled validation workflows:

- vuln_validator.action_mode: exploit_simulation
- vetted PoC static analysis: enabled
- vetted PoC sandbox: enabled
- BloodHound throttle: 500
- no SharpHound --Stealth insertion
- REDTEAM_ACTION logging remains intact

Usage:
    python3 cerberus_patcher.py --root /path/to/cerberus

If --root is omitted, the current working directory is used. The script creates
backups under <root>/backups/ with a timestamp suffix before changing files.
"""
from __future__ import annotations

import argparse
import difflib
import re
import shutil
import sys
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path


@dataclass
class Change:
    file: str
    description: str
    changed: bool


BLOCKED_REQUESTS = [
    "Refused to set action_mode to real 'exploit'; keeping 'exploit_simulation'.",
    "Refused to disable vetted PoC static analysis; keeping require_poc_static_analysis: true.",
    "Refused to disable vetted PoC sandboxing; keeping require_poc_sandbox: true.",
    "Refused to disable BloodHound throttling; keeping bloodhound_throttle: 500.",
    "Refused to inject SharpHound --Stealth.",
    "Refused to remove authorization/safety-gating code blocks automatically.",
]


def backup_file(path: Path, root: Path, timestamp: str) -> Path:
    rel = path.relative_to(root)
    backup_dir = root / "backups" / timestamp / rel.parent
    backup_dir.mkdir(parents=True, exist_ok=True)
    backup_path = backup_dir / f"{path.name}.{timestamp}.bak"
    shutil.copy2(path, backup_path)
    return backup_path


def write_if_changed(path: Path, new_text: str, root: Path, timestamp: str, changes: list[Change], description: str) -> None:
    old_text = path.read_text(encoding="utf-8", errors="replace")
    if old_text == new_text:
        changes.append(Change(str(path.relative_to(root)), description, False))
        return
    backup_file(path, root, timestamp)
    path.write_text(new_text, encoding="utf-8")
    changes.append(Change(str(path.relative_to(root)), description, True))


def patch_redteam_full_block(config_text: str) -> tuple[str, list[str]]:
    """Normalize the redteam_full profile to safe maximum settings.

    This is regex-based to avoid requiring PyYAML in the patching environment.
    It only modifies recognized scalar settings in the redteam_full block.
    """
    notes: list[str] = []
    marker = re.search(r"(?m)^\s{2}redteam_full:\s*$", config_text)
    if not marker:
        notes.append("redteam_full profile not found; no profile changes applied")
        return config_text, notes

    start = marker.start()
    next_profile = re.search(r"(?m)^\s{2}[A-Za-z0-9_\-]+:\s*$", config_text[marker.end():])
    end = marker.end() + next_profile.start() if next_profile else len(config_text)
    prefix, block, suffix = config_text[:start], config_text[start:end], config_text[end:]

    replacements = [
        (r'action_mode:\s*"[^"]+"', 'action_mode: "exploit_simulation"', "set action_mode to exploit_simulation"),
        (r'require_poc_sandbox:\s*(true|false)', 'require_poc_sandbox: true', "require PoC sandbox"),
        (r'require_poc_static_analysis:\s*(true|false)', 'require_poc_static_analysis: true', "require PoC static analysis"),
        (r'bloodhound_throttle:\s*\d+', 'bloodhound_throttle: 500', "set BloodHound throttle to 500"),
        (r'allow_metasploit:\s*(true|false)', 'allow_metasploit: true', "allow Metasploit check/simulation"),
        (r'allow_nuclei:\s*(true|false)', 'allow_nuclei: true', "allow Nuclei verification"),
        (r'allow_vetted_poc:\s*(true|false)', 'allow_vetted_poc: true', "allow vetted PoC under controls"),
        (r'allow_bloodhound:\s*(true|false)', 'allow_bloodhound: true', "allow BloodHound collection under controls"),
        (r'live_acl_if_no_dump:\s*(true|false)', 'live_acl_if_no_dump: true', "enable live ACL fallback"),
        (r'collection_methods:\s*"[^"]+"', 'collection_methods: "ACL,Group,Trusts,ObjectProps,LoggedOn"', "include LoggedOn collection"),
        (r'no_save_cache:\s*(true|false)', 'no_save_cache: true', "enable NoSaveCache"),
    ]
    for pattern, repl, note in replacements:
        new_block, count = re.subn(pattern, repl, block, count=1)
        if count:
            block = new_block
            notes.append(note)
        else:
            notes.append(f"setting not found for: {note}")

    return prefix + block + suffix, notes


def patch_config(path: Path, root: Path, timestamp: str, changes: list[Change]) -> None:
    text = path.read_text(encoding="utf-8", errors="replace")
    new_text, notes = patch_redteam_full_block(text)
    description = "normalize redteam_full to safe maximum profile; " + "; ".join(notes)
    write_if_changed(path, new_text, root, timestamp, changes, description)


def patch_vuln_validator(path: Path, root: Path, timestamp: str, changes: list[Change]) -> None:
    text = path.read_text(encoding="utf-8", errors="replace")
    original = text

    # Ensure exploit_simulation remains explicitly non-executing and logged.
    text = text.replace(
        "This is intentionally a simulation: it logs the exact `exploit -j` resource\n        plan using cmd/*/pingback, runs `check` plus option validation, and stores\n        evidence. It does not execute the exploit job.",
        "This is intentionally a simulation: it logs the exact `exploit -j` resource\n        plan using cmd/*/pingback, runs `check` plus option validation, and stores\n        evidence. It does not execute the exploit job.\n\n        # PATCHED: safe exploit simulation enforced"
    )

    # Guard against accidental real exploit execution introduced by manual edits.
    dangerous_patterns = [
        (r'"exploit -j -z"', '"exploit -j"'),
        (r"'exploit -j -z'", "'exploit -j'"),
        (r'validation_commands\s*=\s*simulation_plan', 'validation_commands = commands + [f"set PAYLOAD {payload}", f"set LHOST {self.pingback_host}", "check", "show options", "exit -y"]'),
    ]
    for pattern, repl in dangerous_patterns:
        text = re.sub(pattern, repl, text)

    # Ensure direct PoC execution remains unavailable in this safe patcher.
    if "profile requires sandboxed PoC execution for safe operation" not in text:
        text = text.replace(
            'if not self.require_poc_sandbox:\n            return {"status": "skipped", "reason": "profile requires sandboxed PoC execution for safe operation", "analysis": analysis}',
            'if not self.require_poc_sandbox:\n            return {"status": "skipped", "reason": "profile requires sandboxed PoC execution for safe operation", "analysis": analysis}'
        )

    desc = "enforce non-destructive exploit_simulation and sandboxed vetted PoC execution"
    if text == original:
        changes.append(Change(str(path.relative_to(root)), desc, False))
    else:
        write_if_changed(path, text, root, timestamp, changes, desc)


def patch_ad_auditor(path: Path, root: Path, timestamp: str, changes: list[Change]) -> None:
    text = path.read_text(encoding="utf-8", errors="replace")
    original = text

    # Remove accidental --Stealth insertion while preserving throttle support.
    text = text.replace('cmd.append("--Stealth")', '# PATCHED: stealth mode disabled; using throttle/no-save-cache controls')
    text = text.replace('cmd.extend(["--Stealth"])', '# PATCHED: stealth mode disabled; using throttle/no-save-cache controls')

    # Ensure throttle block exists in the expected safe form.
    if 'cmd.extend(["--Throttle", str(self.bloodhound_throttle)])' not in text:
        insertion = '''\n        if self.bloodhound_throttle > 0:\n            # PATCHED: load-controlled collection enabled\n            cmd.extend(["--Throttle", str(self.bloodhound_throttle)])\n'''
        text = text.replace(
            'if self.no_save_cache:\n            cmd.append("--NoSaveCache")\n',
            'if self.no_save_cache:\n            cmd.append("--NoSaveCache")\n' + insertion
        )
    else:
        text = text.replace(
            'if self.bloodhound_throttle > 0:\n            cmd.extend(["--Throttle", str(self.bloodhound_throttle)])',
            'if self.bloodhound_throttle > 0:\n            # PATCHED: load-controlled collection enabled\n            cmd.extend(["--Throttle", str(self.bloodhound_throttle)])'
        )

    desc = "enforce BloodHound load control with --Throttle; do not enable stealth mode"
    if text == original:
        changes.append(Change(str(path.relative_to(root)), desc, False))
    else:
        write_if_changed(path, text, root, timestamp, changes, desc)


def find_required_files(root: Path) -> dict[str, Path]:
    candidates = {
        "config": [root / "config.yaml", root / "cerberus" / "config.yaml"],
        "vuln": [root / "modules" / "post_exploit" / "vuln_validator.py", root / "cerberus" / "modules" / "post_exploit" / "vuln_validator.py"],
        "ad": [root / "modules" / "post_exploit" / "ad_auditor.py", root / "cerberus" / "modules" / "post_exploit" / "ad_auditor.py"],
    }
    resolved: dict[str, Path] = {}
    missing: list[str] = []
    for key, paths in candidates.items():
        found = next((p for p in paths if p.exists()), None)
        if found:
            resolved[key] = found
        else:
            missing.append(key)
    if missing:
        raise FileNotFoundError(f"Missing required files for: {', '.join(missing)} under root {root}")
    return resolved


def print_report(changes: list[Change], root: Path, timestamp: str) -> None:
    print("Cerberus safe patcher completed")
    print(f"Root: {root}")
    print(f"Backup directory: {root / 'backups' / timestamp}")
    print("\nPolicy-preserving decisions:")
    for item in BLOCKED_REQUESTS:
        print(f"  - {item}")
    print("\nFile changes:")
    for ch in changes:
        status = "CHANGED" if ch.changed else "UNCHANGED"
        print(f"  [{status}] {ch.file}: {ch.description}")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Patch Cerberus v1.0 sources using a safety-preserving Red Team profile.")
    parser.add_argument("--root", default=".", help="Cerberus project root. Default: current directory")
    args = parser.parse_args(argv)

    root = Path(args.root).resolve()
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    changes: list[Change] = []

    try:
        files = find_required_files(root)
        patch_config(files["config"], root, timestamp, changes)
        patch_vuln_validator(files["vuln"], root, timestamp, changes)
        patch_ad_auditor(files["ad"], root, timestamp, changes)
        print_report(changes, root, timestamp)
        return 0
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
