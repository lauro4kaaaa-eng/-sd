#!/usr/bin/env python3
"""
Safety-preserving Cerberus post-exploitation profile patcher.

This script intentionally does not enable real exploitation, stealth collection,
removal of authorization checks, or direct PoC execution. It performs textual
post-processing that keeps Cerberus in the previously implemented safe Red Team
maximum profile:

- action_mode: "exploit_simulation"
- require_poc_sandbox: true
- require_poc_static_analysis: true
- bloodhound_throttle: 500
- BloodHound LoggedOn collection allowed, but no --Stealth rewrite
- REDTEAM_ACTION logging preserved

Backups are created next to the project in backups/<timestamp>/.

Usage:
  python3 apply_redteam_patches.py --root /path/to/cerberus
"""
from __future__ import annotations

import argparse
import re
import shutil
import sys
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path


@dataclass
class FileStatus:
    path: Path
    changed: bool
    message: str


def backup(path: Path, root: Path, stamp: str) -> Path:
    rel = path.relative_to(root)
    dst_dir = root / "backups" / stamp / rel.parent
    dst_dir.mkdir(parents=True, exist_ok=True)
    dst = dst_dir / f"{path.name}.{stamp}.bak"
    shutil.copy2(path, dst)
    return dst


def write_changed(path: Path, root: Path, stamp: str, new_text: str, message: str) -> FileStatus:
    old_text = path.read_text(encoding="utf-8", errors="replace")
    if old_text == new_text:
        return FileStatus(path, False, message)
    backup(path, root, stamp)
    path.write_text(new_text, encoding="utf-8")
    return FileStatus(path, True, message)


def find_file(root: Path, *candidates: str) -> Path:
    for c in candidates:
        p = root / c
        if p.exists():
            return p
    raise FileNotFoundError(f"None of these files exist under {root}: {', '.join(candidates)}")


def replace_in_redteam_full_block(text: str) -> tuple[str, list[str]]:
    notes: list[str] = []
    m = re.search(r"(?m)^\s{2}redteam_full:\s*$", text)
    if not m:
        return text, ["profiles.redteam_full not found"]

    start = m.start()
    next_profile = re.search(r"(?m)^\s{2}[A-Za-z0-9_-]+:\s*$", text[m.end():])
    end = m.end() + next_profile.start() if next_profile else len(text)
    prefix, block, suffix = text[:start], text[start:end], text[end:]

    safe_replacements = [
        (r'action_mode:\s*"[^"]+"', 'action_mode: "exploit_simulation"', "kept exploit_simulation"),
        (r'require_poc_sandbox:\s*(true|false)', 'require_poc_sandbox: true', "kept PoC sandbox required"),
        (r'require_poc_static_analysis:\s*(true|false)', 'require_poc_static_analysis: true', "kept static analysis required"),
        (r'bloodhound_throttle:\s*\d+', 'bloodhound_throttle: 500', "kept BloodHound throttle at 500"),
        (r'collection_methods:\s*"[^"]+"', 'collection_methods: "ACL,Group,Trusts,ObjectProps,LoggedOn"', "ensured LoggedOn collection method"),
        (r'allow_metasploit:\s*(true|false)', 'allow_metasploit: true', "enabled Metasploit check/simulation"),
        (r'allow_nuclei:\s*(true|false)', 'allow_nuclei: true', "enabled Nuclei"),
        (r'allow_vetted_poc:\s*(true|false)', 'allow_vetted_poc: true', "enabled vetted PoC with controls"),
        (r'allow_bloodhound:\s*(true|false)', 'allow_bloodhound: true', "enabled BloodHound with controls"),
        (r'live_acl_if_no_dump:\s*(true|false)', 'live_acl_if_no_dump: true', "enabled live ACL fallback"),
    ]
    for pattern, repl, note in safe_replacements:
        block, count = re.subn(pattern, repl, block, count=1)
        notes.append(note if count else f"not found: {note}")

    return prefix + block + suffix, notes


def patch_config(root: Path, stamp: str) -> FileStatus:
    path = find_file(root, "config.yaml", "cerberus/config.yaml")
    text = path.read_text(encoding="utf-8", errors="replace")
    new_text, notes = replace_in_redteam_full_block(text)
    return write_changed(path, root, stamp, new_text, "; ".join(notes))


def patch_vuln_validator(root: Path, stamp: str) -> FileStatus:
    path = find_file(root, "modules/post_exploit/vuln_validator.py", "cerberus/modules/post_exploit/vuln_validator.py")
    text = path.read_text(encoding="utf-8", errors="replace")

    # Safety-preserving normalization: if a prior manual patch inserted real exploit
    # execution, return it to exploit_simulation validation.
    new_text = text.replace('"exploit -j -z"', '"exploit -j"')
    new_text = new_text.replace("'exploit -j -z'", "'exploit -j'")
    new_text = new_text.replace("# PATCHED: real exploit enabled", "# PATCHED: safe exploit simulation preserved")

    return write_changed(path, root, stamp, new_text, "preserved exploit_simulation; did not enable real exploit execution")


def patch_ad_auditor(root: Path, stamp: str) -> FileStatus:
    path = find_file(root, "modules/post_exploit/ad_auditor.py", "cerberus/modules/post_exploit/ad_auditor.py")
    text = path.read_text(encoding="utf-8", errors="replace")

    # Safety-preserving normalization: do not rewrite Throttle to Stealth.
    new_text = text.replace('"--Stealth"', '"--Throttle"')
    new_text = new_text.replace("# PATCHED: stealth mode enabled", "# PATCHED: load-controlled collection enabled")

    return write_changed(path, root, stamp, new_text, "preserved --Throttle load control; did not enable --Stealth")


def scan_authorization_blocks(root: Path) -> list[str]:
    findings: list[str] = []
    post_dir_candidates = [root / "modules" / "post_exploit", root / "cerberus" / "modules" / "post_exploit"]
    post_dir = next((p for p in post_dir_candidates if p.exists()), None)
    if not post_dir:
        return ["modules/post_exploit not found"]
    needle = "if not self.config.get('red_team', {}).get('authorized_operation'):"
    for py in post_dir.rglob("*.py"):
        text = py.read_text(encoding="utf-8", errors="replace")
        if needle in text:
            findings.append(str(py.relative_to(root)))
    return findings


def main() -> int:
    parser = argparse.ArgumentParser(description="Apply safe Red Team profile patches to Cerberus sources.")
    parser.add_argument("--root", default=".", help="Project root. Default: current directory")
    args = parser.parse_args()

    root = Path(args.root).resolve()
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")

    try:
        statuses = [
            patch_config(root, stamp),
            patch_vuln_validator(root, stamp),
            patch_ad_auditor(root, stamp),
        ]
        auth_findings = scan_authorization_blocks(root)

        print("apply_redteam_patches.py completed in safety-preserving mode")
        print(f"Root: {root}")
        print(f"Backups: {root / 'backups' / stamp}")
        print("\nChanges:")
        for st in statuses:
            print(f"  [{'CHANGED' if st.changed else 'UNCHANGED'}] {st.path.relative_to(root)} — {st.message}")

        print("\nSafety decisions:")
        print("  - Did not change action_mode to real exploit.")
        print("  - Did not disable PoC sandbox/static analysis.")
        print("  - Did not disable BloodHound throttling.")
        print("  - Did not rewrite --Throttle to --Stealth.")
        print("  - Did not delete authorization/safety blocks automatically.")

        if auth_findings:
            print("\nAuthorization-gate references found, left unchanged:")
            for item in auth_findings:
                print(f"  - {item}")
        return 0
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
