def build_hydra_cmd(target, service, user_list, pass_list):
    # hydra -L users.txt -P pass.txt target service
    # -f: exit after first found login/password pair
    # -I: Ignore existing restore file
    return ["hydra", "-L", user_list, "-P", pass_list, f"{service}://{target}", "-f", "-I"]

def parse_hydra_output(output):
    valid_creds = []
    for line in output.splitlines():
        if "login:" in line.lower() and "password:" in line.lower():
            valid_creds.append(line.strip())
    return valid_creds