import asyncio
import subprocess
import logging

class ScanManager:
    def __init__(self, max_concurrent=5):
        self.queue = asyncio.PriorityQueue()
        self.semaphore = asyncio.Semaphore(max_concurrent)
        self.results = []

    async def add_task(self, priority, task_id, cmd, parser_func=None):
        await self.queue.put((priority, task_id, cmd, parser_func))

    async def worker(self):
        while not self.queue.empty():
            priority, task_id, cmd, parser_func = await self.queue.get()
            async with self.semaphore:
                logging.info(f"Starting task {task_id}: {' '.join(cmd)}")
                try:
                    proc = await asyncio.create_subprocess_exec(
                        *cmd,
                        stdout=asyncio.subprocess.PIPE,
                        stderr=asyncio.subprocess.PIPE
                    )
                    stdout, stderr = await proc.communicate()
                    
                    result_data = stdout.decode('utf-8', errors='replace')
                    if parser_func:
                        result_data = parser_func(result_data)
                        
                    self.results.append({'task_id': task_id, 'status': 'success', 'data': result_data})
                except Exception as e:
                    self.results.append({'task_id': task_id, 'status': 'error', 'error': str(e)})
            self.queue.task_done()

    async def run(self):
        workers = [asyncio.create_task(self.worker()) for _ in range(self.semaphore._value)]
        await asyncio.gather(*workers)
        return self.results