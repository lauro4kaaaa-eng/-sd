import json

def build_nuclei_cmd(target, templates_dir=None):
    # -json-export -: Export results in JSON format to stdout
    cmd = ["nuclei", "-u", target, "-json-export", "-"]
    if templates_dir:
        cmd.extend(["-t", templates_dir])
    return cmd

def parse_nuclei_json(output):
    results = []
    for line in output.splitlines():
        if line.strip():
            try:
                results.append(json.loads(line))
            except:
                pass
    return results