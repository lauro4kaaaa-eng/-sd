import asyncio
import logging
from orchestrator import ScanManager
from recon import build_nmap_cmd, parse_nmap_xml
from vulnscan import build_nuclei_cmd, parse_nuclei_json
from brute import build_hydra_cmd, parse_hydra_output
from db import Database

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

async def run_pipeline(target):
    db = Database()
    
    # Init project
    db.conn.execute("INSERT INTO projects (name) VALUES ('Audit TIBER-EU')")
    project_id = db.conn.execute("SELECT last_insert_rowid()").fetchone()[0]

    manager = ScanManager(max_concurrent=3)
    
    # 1. Recon Stage
    logging.info(f"Starting Recon phase for {target}")
    await manager.add_task(1, f"recon_{target}", build_nmap_cmd(target), parse_nmap_xml)
    recon_results = await manager.run()
    
    open_ports = []
    for res in recon_results:
        if res['status'] == 'success':
            db.add_result(project_id, 'recon', target, str(res['data']))
            open_ports.extend(res['data'] if isinstance(res['data'], list) else [])
        else:
            db.add_result(project_id, 'recon', target, res.get('error', ''), 'error')

    # 2. VulnScan Stage (Nuclei) & 3. Brute Stage (Hydra)
    logging.info(f"Starting VulnScan and Auditing phase for {target}")
    manager = ScanManager(max_concurrent=3)
    
    for port_info in open_ports:
        if not isinstance(port_info, dict): continue
        
        port = port_info.get('port')
        service = port_info.get('service', '')
        
        # Pipeline VulnScan on Web services
        if 'http' in service:
            url = f"http://{target}:{port}"
            await manager.add_task(2, f"vuln_{url}", build_nuclei_cmd(url), parse_nuclei_json)
            
        # Pipeline Brute on specific protocols (e.g. ssh, ftp)
        if service in ['ssh', 'ftp', 'telnet']:
            # Example using default wordlists (in a real scenario, these paths would be config-driven)
            users_list = "/usr/share/wordlists/users.txt"
            pass_list = "/usr/share/wordlists/passwords.txt"
            await manager.add_task(3, f"brute_{service}_{target}", build_hydra_cmd(target, service, users_list, pass_list), parse_hydra_output)
    
    audit_results = await manager.run()
    
    # Save final results to DB
    for res in audit_results:
        module_name = 'vulnscan' if 'vuln' in res['task_id'] else 'brute'
        if res['status'] == 'success':
            db.add_result(project_id, module_name, target, str(res['data']))
        else:
            db.add_result(project_id, module_name, target, res.get('error', ''), 'error')

    logging.info("Pipeline completed successfully.")

if __name__ == "__main__":
    # Example execution
    asyncio.run(run_pipeline("127.0.0.1"))