import sqlite3

class Database:
    def __init__(self, db_name="cerberus.db"):
        self.conn = sqlite3.connect(db_name)
        self.create_tables()

    def create_tables(self):
        cursor = self.conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS projects (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL
            )
        ''')
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS results (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                project_id INTEGER,
                module TEXT,
                target TEXT,
                data TEXT,
                status TEXT,
                FOREIGN KEY(project_id) REFERENCES projects(id)
            )
        ''')
        self.conn.commit()

    def add_result(self, project_id, module, target, data, status="success"):
        cursor = self.conn.cursor()
        cursor.execute('''
            INSERT INTO results (project_id, module, target, data, status)
            VALUES (?, ?, ?, ?, ?)
        ''', (project_id, module, target, data, status))
        self.conn.commit()