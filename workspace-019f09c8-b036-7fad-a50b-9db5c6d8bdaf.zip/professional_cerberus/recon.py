import json
import xml.etree.ElementTree as ET

def build_nmap_cmd(target):
    # -sV: Probe open ports to determine service/version info
    # -oX -: Output in XML format to stdout
    return ["nmap", "-sV", "-oX", "-", target]

def parse_nmap_xml(xml_data):
    try:
        root = ET.fromstring(xml_data)
        ports = []
        for host in root.findall('host'):
            for port in host.findall('.//port'):
                state = port.find('state').get('state')
                if state == 'open':
                    portid = port.get('portid')
                    service = port.find('service')
                    svc_name = service.get('name') if service is not None else 'unknown'
                    ports.append({'port': portid, 'service': svc_name})
        return ports
    except Exception as e:
        return {"error": "Failed to parse Nmap output", "details": str(e)}

def build_masscan_cmd(target, ports="1-65535", rate="1000"):
    # -oJ -: Output in JSON format to stdout
    return ["masscan", target, "-p", ports, "--rate", rate, "-oJ", "-"]

def parse_masscan_json(json_data):
    try:
        return json.loads(json_data)
    except Exception as e:
        return {"error": "Failed to parse Masscan output", "details": str(e)}