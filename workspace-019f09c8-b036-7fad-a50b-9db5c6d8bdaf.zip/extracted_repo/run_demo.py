import asyncio
import logging
import sys
from cerberus.core.orchestrator import Orchestrator
from cerberus.core.models import TaskStatus

async def main():
    logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')
    orch = Orchestrator({"task_timeout": 5})
    await orch.start(worker_count=2)

    print("\n--- Отправка задач ---")
    t1 = await orch.submit("mock", "google.com", {"delay": 2})
    t2 = await orch.submit("mock", "fail", {"delay": 1})
    
    print(f"Task 1 (Success expected) ID: {t1} Status: {orch.get_state(t1).status.name}")
    print(f"Task 2 (Fail expected) ID: {t2} Status: {orch.get_state(t2).status.name}")

    # Мониторинг в реальном времени
    for _ in range(5):
        await asyncio.sleep(0.5)
        s1 = orch.get_state(t1).status.name
        s2 = orch.get_state(t2).status.name
        print(f"Polling... T1: {s1}, T2: {s2}")

    await orch.queue.join()
    print("--- Очередь пуста ---")
    print(f"T1 Result: {orch.get_state(t1).status.name} Data: {orch.get_state(t1).result}")
    print(f"T2 Result: {orch.get_state(t2).status.name} Error: {orch.get_state(t2).error}")

    await orch.stop()
    print("Orchestrator Shutdown Complete.")

if __name__ == "__main__":
    # Настройка PYTHONPATH
    import os
    sys.path.append(os.getcwd())
    asyncio.run(main())
