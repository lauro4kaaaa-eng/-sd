from fastapi import FastAPI
from fastapi.responses import HTMLResponse
import aiosqlite
import json
import uvicorn

app = FastAPI()

HTML_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <title>Cerberus v1.5 Dashboard</title>
    <style>
        body { font-family: monospace; background: #0b0e14; color: #00ffcc; padding: 20px; }
        .card { background: #151a24; padding: 20px; border-radius: 5px; border: 1px solid #00ffcc55; margin-bottom: 20px; }
        h1 { color: #ff0055; text-align: center; border-bottom: 2px solid #ff0055; padding-bottom: 10px; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 10px; text-align: left; border-bottom: 1px solid #00ffcc22; }
        .stat { color: #fff; font-weight: bold; }
    </style>
</head>
<body>
    <h1>CERBERUS OPERATIONAL DASHBOARD</h1>
    <div class="card">
        <h3>Live Loot Feed</h3>
        <div id="feed">Waiting for data...</div>
    </div>
    <script>
        async function update() {
            const r = await fetch('/api/stats');
            const d = await r.json();
            document.getElementById('feed').innerHTML = d.recent.length ? 
                '<table><tr><th>Target</th><th>Module</th><th>Time</th></tr>' + 
                d.recent.map(x => `<tr><td>${x.target}</td><td>${x.module}</td><td>${x.timestamp}</td></tr>`).join('') + 
                '</table>' : 'No data in database yet.';
        }
        setInterval(update, 2000);
        update();
    </script>
</body>
</html>
"""

@app.get("/", response_class=HTMLResponse)
async def index():
    return HTML_TEMPLATE

@app.get("/api/stats")
async def get_stats():
    try:
        async with aiosqlite.connect("cerberus.db") as db:
            db.row_factory = aiosqlite.Row
            async with db.execute("SELECT * FROM loot ORDER BY timestamp DESC LIMIT 10") as cursor:
                rows = await cursor.fetchall()
                return {"recent": [dict(r) for r in rows]}
    except:
        return {"recent": []}

def start_ui():
    uvicorn.run(app, host="127.0.0.1", port=8080, log_level="error")
