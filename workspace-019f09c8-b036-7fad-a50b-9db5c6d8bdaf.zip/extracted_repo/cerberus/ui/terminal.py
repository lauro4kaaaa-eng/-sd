from colorama import Fore, Style, init
import time
import sys

init(autoreset=True)

BANNER = f"""
{Fore.CYAN}{Style.BRIGHT}
 ██████╗███████╗██████╗ ██████╗ ███████╗██████╗ ██╗   ██╗███████╗
██╔════╝██╔════╝██╔══██╗██╔══██╗██╔════╝██╔══██╗██║   ██║██╔════╝
██║     █████╗  ██████╔╝██████╔╝█████╗  ██████╔╝██║   ██║███████╗
██║     ██╔════╝██╔══██╗██╔══██╗██╔════╝██╔══██╗██║   ██║╚════██║
╚██████╗███████╗██║  ██║██████╔╝███████╗██║  ██║╚██████╔╝███████║
 ╚═════╝╚══════╝╚═╝  ╚═╝╚═════╝ ╚══════╝╚═╝  ╚═╝ ╚═════╝ ╚══════╝
           {Fore.WHITE}»»» {Fore.RED}V5.0 BLACK ZENITH EDITION {Fore.WHITE}«««
           {Fore.YELLOW}Advanced IoT Exploitation Framework
"""

def startup_animation():
    print(BANNER)
    steps = [
        "Initializing Neural Link...",
        "Loading Exploit Signatures...",
        "Establishing Database Connection...",
        "Ghost Protocol: ACTIVE",
        "Targeting Systems: READY"
    ]
    for step in steps:
        sys.stdout.write(f"{Fore.CYAN}[*] {step}")
        time.sleep(0.3)
        sys.stdout.write(f"\r{Fore.GREEN}[+] {step}\n")
    print(f"\n{Fore.WHITE}{'='*60}\n")

def print_status(msg, type="info"):
    colors = {"info": Fore.CYAN, "success": Fore.GREEN, "warn": Fore.YELLOW, "error": Fore.RED}
    symbol = {"info": "[*]", "success": "[+]", "warn": "[!]", "error": "[-]"}
    print(f"{colors.get(type, Fore.WHITE)}{symbol.get(type, '[ ]')} {msg}")
