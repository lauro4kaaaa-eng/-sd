import asyncio
import time
import logging
from cerberus.core.orchestrator import Orchestrator
from cerberus.core.db import Database
from cerberus.core.models import TaskStatus

async def run_benchmark(num_tasks: int = 1000, workers: int = 50):
    logging.basicConfig(level=logging.WARNING)
    db = Database("benchmark.db")
    await db.initialize()
    
    orch = Orchestrator({"task_timeout": 5})
    await orch.start(worker_count=workers)
    
    start_time = time.perf_counter()
    
    print(f"[*] Sending {num_tasks} tasks to {workers} workers...")
    
    # Массовая подача задач
    t_ids = []
    for i in range(num_tasks):
        t_id = await orch.submit("mock", f"target_{i}", {"delay": 0.05})
        t_ids.append(t_id)

    # Ожидание завершения
    await orch.queue.join()
    
    total_time = time.perf_counter() - start_time
    
    # Аналитика
    results = [orch.get_state(tid) for tid in t_ids]
    completed = [r for r in results if r.status == TaskStatus.COMPLETED]
    failed = [r for r in results if r.status == TaskStatus.FAILED]
    
    print(f"\n--- Benchmark Results ---")
    print(f"Total tasks: {num_tasks}")
    print(f"Success: {len(completed)}")
    print(f"Failed: {len(failed)}")
    print(f"Time taken: {total_time:.2f}s")
    print(f"Throughput: {num_tasks / total_time:.2f} tasks/sec")
    
    await orch.stop()

if __name__ == "__main__":
    asyncio.run(run_benchmark(1000, 50))
