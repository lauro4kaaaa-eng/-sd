import asyncio
import aiohttp
from typing import Dict, Any

class Scanner:
    def __init__(self, config: Dict[str, Any]):
        self.config = config

    async def run(self, target: str, options: Dict[str, Any]) -> Dict[str, Any]:
        """Безопасный сбор метаданных сервиса."""
        url = f"http://{target}" if not target.startswith("http") else target
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(url, timeout=5, allow_redirects=True) as resp:
                    return {
                        "status": resp.status,
                        "server": resp.headers.get("Server", "Unknown"),
                        "content_type": resp.headers.get("Content-Type"),
                        "final_url": str(resp.url)
                    }
        except Exception as e:
            return {"error": str(e)}
