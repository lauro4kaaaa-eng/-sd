from flask import Flask, render_template_string
import os

app = Flask(__name__, static_folder='../loot/snapshots', static_url_path='/static')

HTML_TEMPLATE = """
<html>
<head>
    <title>CERBERUS LIVE GALLERY</title>
    <style>
        body { background: #050505; color: #00ff41; font-family: monospace; }
        .grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 10px; padding: 20px; }
        .cam-card { border: 1px solid #00ff41; padding: 10px; background: #111; position: relative; }
        img { width: 100%; border-bottom: 1px solid #00ff41; height: 200px; object-fit: cover; }
        .info { font-size: 11px; margin-top: 5px; color: #aaa; }
        h1 { text-align: center; border-bottom: 2px solid #00ff41; padding: 10px; color: #00ff41; }
    </style>
</head>
<body>
    <h1>[ CERBERUS OVERLORD - LIVE FEED ]</h1>
    <div class="grid">
        {% for snap in snapshots %}
        <div class="cam-card">
            <img src="/static/{{ snap }}">
            <div class="info">TARGET: {{ snap.split('_')[0] }}<br>CAPTURED: {{ snap.split('_')[1].split('.')[0] }}</div>
        </div>
        {% endfor %}
    </div>
</body>
</html>
"""

@app.route('/')
def index():
    path = 'loot/snapshots'
    if not os.path.exists(path):
        os.makedirs(path, exist_ok=True)
    try:
        snaps = [f for f in os.listdir(path) if f.lower().endswith(('.png', '.jpg', '.jpeg'))]
        snaps.sort(reverse=True) # Показываем свежие первыми
    except:
        snaps = []
    return render_template_string(HTML_TEMPLATE, snapshots=snaps)

def run_web_ui():
    app.run(host='127.0.0.1', port=8080, debug=False)
