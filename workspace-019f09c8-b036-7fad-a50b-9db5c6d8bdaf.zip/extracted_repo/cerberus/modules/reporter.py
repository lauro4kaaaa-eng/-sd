import json
import os
from datetime import datetime
from ui.terminal import Fore, Style

class Reporter:
    def __init__(self, base_dir="reports"):
        self.base_dir = base_dir
        if not os.path.exists(self.base_dir):
            os.makedirs(self.base_dir)

    def generate_report_name(self, target, ext="json"):
        # Очистка имени цели для файла (замена / на _)
        target_clean = str(target).replace("/", "_").replace(".", "_")
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        return os.path.join(self.base_dir, f"audit_{target_clean}_{timestamp}.{ext}")

    def save_results(self, target, data):
        if not data:
            return None

        json_file = self.generate_report_name(target, "json")
        txt_file = self.generate_report_name(target, "txt")

        # Сохранение JSON
        with open(json_file, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=4, ensure_ascii=False)

        # Сохранение читаемого лога
        with open(txt_file, 'w', encoding='utf-8') as f:
            f.write(f"CERBERUS AUDIT REPORT\n")
            f.write(f"Target: {target}\n")
            f.write(f"Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write("="*50 + "\n\n")
            
            for host in data:
                f.write(f"[*] HOST: {host['ip']}\n")
                f.write(f"    Vendor: {host.get('vendor', 'Unknown')}\n")
                f.write(f"    Ports: {host.get('ports', [])}\n")
                if host.get('vulns'):
                    f.write(f"    [!] VULNERABILITIES FOUND:\n")
                    for v in host['vulns']:
                        f.write(f"        - {v}\n")
                f.write("-" * 30 + "\n")

        return txt_file
