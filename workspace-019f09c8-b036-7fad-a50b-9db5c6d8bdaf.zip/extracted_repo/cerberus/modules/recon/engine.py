import asyncio
from typing import Dict, Any, List, Optional

class Scanner:
    def __init__(self, config: Dict[str, Any]):
        self.config = config

    async def check_port(self, target: str, port: int, timeout: float = 1.0) -> Optional[int]:
        try:
            # Используем asyncio.wait_for вокруг open_connection
            conn = asyncio.open_connection(target, port)
            _, writer = await asyncio.wait_for(conn, timeout=timeout)
            writer.close()
            await writer.wait_closed()
            return port
        except:
            return None

    async def run(self, target: str, options: Dict[str, Any]) -> Dict[str, Any]:
        ports = options.get("ports", [80, 443, 554, 8000, 8080, 37777])
        timeout = options.get("timeout", 1.0)
        
        tasks = [self.check_port(target, port, timeout) for port in ports]
        results = await asyncio.gather(*tasks)
        
        open_ports = [p for p in results if p is not None]
        return {
            "ip": target,
            "open_ports": open_ports,
            "count": len(open_ports)
        }
