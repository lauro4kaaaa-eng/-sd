import asyncio
import subprocess
import json
import os
from typing import Dict

class Module:
    def __init__(self, config):
        self.config = config
        self.name = "Recon"

    async def run(self, target: str, options: Dict):
        results = {
            "target": target,
            "passive": await self.passive_collect(target),
            "active": await self.active_scan(target, options.get('ports', 'top-100'))
        }
        return results

    async def passive_collect(self, target):
        # Интеграция с Shodan/Censys (пример вызова Shodan)
        # В реальности здесь вызовы через aiohttp к API
        return {"shodan": "data_placeholder", "crt_sh": []}

    async def active_scan(self, target, ports):
        """Асинхронная обертка над Masscan/Nmap"""
        print(f"[*] Запуск активного сканирования: {target}")
        # Пример вызова masscan для скорости
        cmd = f"sudo masscan {target} -p{ports} --rate 1000 --json"
        try:
            proc = await asyncio.create_subprocess_shell(
                cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            stdout, stderr = await proc.communicate()
            if stdout:
                return json.loads(stdout.decode())
        except Exception as e:
            return {"error": str(e)}
        return []
