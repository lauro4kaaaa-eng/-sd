# cerberus/modules/recon/fast_scanner.py
import asyncio
from scapy.all import IP, TCP, sr1, conf
import socket
import logging

logging.getLogger("scapy.runtime").setLevel(logging.ERROR)

class RawScanner:
    def __init__(self, timeout=1.0):
        self.timeout = timeout
        conf.verb = 0 # Silent scapy

    async def syn_check(self, target: str, port: int) -> bool:
        """Реализация скрытного SYN-сканирования"""
        loop = asyncio.get_event_loop()
        try:
            # Создаем SYN пакет
            packet = IP(dst=target)/TCP(dport=port, flags="S")
            # Отправляем асинхронно
            response = await loop.run_in_executor(None, lambda: sr1(packet, timeout=self.timeout, verbose=0))
            
            if response and response.haslayer(TCP):
                if response.getlayer(TCP).flags == 0x12: # SYN-ACK
                    # Отправляем RST, чтобы закрыть соединение скрытно
                    rst_packet = IP(dst=target)/TCP(dport=port, flags="R")
                    await loop.run_in_executor(None, lambda: sr1(rst_packet, timeout=self.timeout, verbose=0))
                    return True
        except Exception:
            return False
        return False

    async def scan_range(self, target_ip: str, ports: list):
        tasks = [self.syn_check(target_ip, port) for port in ports]
        results = await asyncio.gather(*tasks)
        return [ports[i] for i, opened in enumerate(results) if opened]
