import asyncio
import os
import re

class ReconModule:
    async def mass_scan(self, target, rate=1000):
        tmp_file = ".masscan_out"
        # Запускаем masscan
        cmd = f"sudo masscan {target} -p80,443,554,8000,8080,37777 --rate {rate} -oG {tmp_file}"
        
        try:
            process = await asyncio.create_subprocess_shell(
                cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
            )
            await process.communicate()
        except Exception as e:
            print(f"Masscan error: {e}")
            return []
        
        found_hosts = {}
        if os.path.exists(tmp_file):
            with open(tmp_file, 'r') as f:
                for line in f:
                    # Ищем IP и Порт с помощью регулярных выражений
                    # Формат: Host: 95.154.242.118 () Ports: 554/open/tcp//rtsp//
                    ip_match = re.search(r"Host:\s+([0-9.]+)", line)
                    port_match = re.search(r"Ports:\s+([0-9]+)", line)
                    
                    if ip_match and port_match:
                        ip = ip_match.group(1)
                        port = int(port_match.group(1))
                        
                        if ip not in found_hosts:
                            found_hosts[ip] = {"ip": ip, "ports": [], "vendor": "Unknown"}
                        if port not in found_hosts[ip]["ports"]:
                            found_hosts[ip]["ports"].append(port)
            
            os.remove(tmp_file)
        
        return list(found_hosts.values())

    async def scan_target_nmap(self, target):
        return await self.mass_scan(target, 100)
