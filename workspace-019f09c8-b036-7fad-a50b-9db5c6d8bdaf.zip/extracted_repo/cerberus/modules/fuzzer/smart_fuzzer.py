# cerberus/modules/fuzzer/smart_fuzzer.py
import aiohttp
import asyncio
import time
import re
import numpy as np

class SmartFuzzer:
    def __init__(self, target, config):
        self.target = target
        self.config = config
        self.token = None
        self.baseline = {"status": None, "size": 0, "time": 0}

    async def learn_baseline(self, session):
        times, sizes = [], []
        for _ in range(3):
            start = time.time()
            async with session.get(self.target) as r:
                times.append(time.time() - start)
                sizes.append(len(await r.read()))
                self.baseline["status"] = r.status
        self.baseline["time"] = np.mean(times) if times else 0
        self.baseline["size"] = np.mean(sizes) if sizes else 0

    def is_anomaly(self, status, size, elapsed):
        if status != self.baseline["status"]: return True
        if self.baseline["size"] > 0 and abs(size - self.baseline["size"]) / self.baseline["size"] > 0.2: return True
        if elapsed > self.baseline["time"] + 2.0: return True
        return False

    async def fuzz(self, url, params, token=None):
        headers = self.config.get('web', {}).get('headers', {}).copy()
        if token: headers["Authorization"] = f"Bearer {token}"
        
        async with aiohttp.ClientSession(headers=headers) as session:
            await self.learn_baseline(session)
            for p_name, p_val in params.items():
                payload = f"'{p_val}\" -- sleep(5)"
                start = time.time()
                try:
                    async with session.get(url, params={p_name: payload}, timeout=15) as r:
                        elapsed = time.time() - start
                        size = len(await r.read())
                        if self.is_anomaly(r.status, size, elapsed):
                            return {"url": url, "param": p_name, "type": "Anomaly Detected"}
                except: pass
        return None
