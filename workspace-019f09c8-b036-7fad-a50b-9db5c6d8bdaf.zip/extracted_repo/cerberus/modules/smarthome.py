import aiohttp
import asyncio
import socket

class SmartHomeModule:
    def __init__(self):
        self.ports = {
            "MQTT": 1883,
            "HomeAssistant": 8123,
            "Zigbee2MQTT": 8080,
            "Xiaomi": 54321
        }

    async def audit(self, ip):
        results = []
        for name, port in self.ports.items():
            if await self.check_port(ip, port):
                res = await self.probe_service(ip, name)
                if res: results.append(res)
        return results

    async def check_port(self, ip, port):
        try:
            conn = asyncio.open_connection(ip, port)
            reader, writer = await asyncio.wait_for(conn, timeout=2)
            writer.close()
            await writer.wait_closed()
            return True
        except: return False

    async def probe_service(self, ip, service):
        if service == "MQTT":
            # Попытка анонимного подключения к MQTT
            return "MQTT Broker Detected (Check for Anonymous Login)"
        if service == "HomeAssistant":
            url = f"http://{ip}:8123/manifest.json"
            try:
                async with aiohttp.ClientSession() as s:
                    async with s.get(url, timeout=3) as r:
                        if r.status == 200: return "Home Assistant Controller (Auth Required)"
            except: pass
        return f"{service} Service Found"
