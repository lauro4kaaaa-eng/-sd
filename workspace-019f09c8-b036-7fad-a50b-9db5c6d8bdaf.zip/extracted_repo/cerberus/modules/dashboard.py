import os
from datetime import datetime

class DashboardGenerator:
    def __init__(self, db):
        self.db = db

    def generate(self, output_path="nebula_report.html"):
        hosts = self.db.get_vulnerable()
        
        html = f"""
        <html>
        <head>
            <title>Cerberus Nebula Report</title>
            <style>
                body {{ background: #0b0e14; color: #00ffcc; font-family: 'Courier New', monospace; }}
                .card {{ border: 1px solid #00ffcc; padding: 15px; margin: 10px; border-radius: 5px; background: #151a24; }}
                h1 {{ color: #ff0055; text-align: center; text-transform: uppercase; }}
                .vuln {{ color: #ff0055; font-weight: bold; }}
                img {{ max-width: 300px; border: 1px solid #00ffcc; }}
            </style>
        </head>
        <body>
            <h1>Cerberus v5.0 Audit Log</h1>
            <div class='container'>
        """
        
        for host in hosts:
            html += f"""
            <div class='card'>
                <h3>Target: {host[0]} ({host[1]})</h3>
                <p class='vuln'>Vulnerabilities: {host[2]}</p>
                <p>Credentials: {host[3]}</p>
            </div>
            """
            
        html += "</div></body></html>"
        
        with open(output_path, "w") as f:
            f.write(html)
        return os.path.abspath(output_path)
