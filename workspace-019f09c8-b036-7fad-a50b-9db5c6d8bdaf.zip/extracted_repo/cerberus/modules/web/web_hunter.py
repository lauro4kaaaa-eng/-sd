# cerberus/modules/web/web_hunter.py
import re
import urllib.parse
from playwright.async_api import async_playwright

class WebHunter:
    def __init__(self, config):
        self.config = config
        self.found_endpoints = set()
        self.blacklist = config.get('web', {}).get('blacklist', [])
        self.max_depth = config.get('web', {}).get('max_depth', 3)

    def is_blacklisted(self, url):
        for pattern in self.blacklist:
            if pattern in url.lower():
                return True
        return False

    async def spider(self, page, start_url):
        to_visit = [(start_url, 0)]
        visited = set()
        domain = urllib.parse.urlparse(start_url).netloc

        while to_visit:
            current_url, depth = to_visit.pop(0)
            if current_url in visited or depth > self.max_depth or self.is_blacklisted(current_url):
                continue
            
            visited.add(current_url)
            try:
                await page.goto(current_url, wait_until="domcontentloaded", timeout=10000)
                links = await page.eval_on_selector_all("a", "elements => elements.map(e => e.href)")
                for link in links:
                    clean_link = link.split('#')[0].rstrip('/')
                    if domain in clean_link and clean_link not in visited:
                        if not self.is_blacklisted(clean_link):
                            self.found_endpoints.add(clean_link)
                            to_visit.append((clean_link, depth + 1))
            except: continue
        return self.found_endpoints
