import asyncio
import json

class Scanner:
    def __init__(self, config):
        self.config = config

    async def run(self, target, options):
        # Nuclei Integration
        cmd = ["nuclei", "-u", target, "-severity", "critical,high", "-jsonl", "-silent"]
        proc = await asyncio.create_subprocess_exec(*cmd, stdout=asyncio.subprocess.PIPE)
        
        while True:
            line = await proc.stdout.readline()
            if not line: break
            vuln = json.loads(line.decode())
            print(f"[!!!] VULNERABILITY FOUND: {vuln['info']['name']} on {target}")
