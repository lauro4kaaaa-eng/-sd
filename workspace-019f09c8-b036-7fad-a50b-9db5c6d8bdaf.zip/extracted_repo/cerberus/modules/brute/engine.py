import asyncio
import aiohttp
from typing import Dict, Any, List, Optional
from aiohttp import BasicAuth

class Scanner:
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        # Небольшой встроенный словарь для теста
        self.default_creds = [
            ("admin", "admin"),
            ("admin", "12345"),
            ("admin", "password"),
            ("root", "root"),
            ("user", "user")
        ]

    async def attempt_login(self, session: aiohttp.ClientSession, url: str, user: str, password: str) -> Optional[tuple]:
        try:
            async with session.get(url, auth=BasicAuth(user, password), timeout=3) as resp:
                if resp.status == 200:
                    return (user, password)
        except:
            pass
        return None

    async def run(self, target: str, options: Dict[str, Any]) -> Dict[str, Any]:
        url = f"http://{target}" if not target.startswith("http") else target
        creds = options.get("wordlist", self.default_creds)
        
        results = []
        async with aiohttp.ClientSession() as session:
            # Ограничиваем параллелизм внутри модуля, чтобы не "положить" цель
            semaphore = asyncio.Semaphore(5)
            
            async def protected_attempt(u, p):
                async with semaphore:
                    return await self.attempt_login(session, url, u, p)

            tasks = [protected_attempt(u, p) for u, p in creds]
            found = await asyncio.gather(*tasks)
            
            valid = [f for f in found if f is not None]
            if valid:
                return {"status": "vulnerable", "valid_creds": valid}
        
        return {"status": "secure", "message": "No default creds found"}
