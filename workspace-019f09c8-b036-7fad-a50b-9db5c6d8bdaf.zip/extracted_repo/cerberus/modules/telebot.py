import aiohttp
import os

class CerberusBot:
    def __init__(self, token, chat_id):
        self.token = token
        self.chat_id = chat_id
        self.api_url = f"https://api.telegram.org/bot{token}"

    async def send_message(self, text):
        url = f"{self.api_url}/sendMessage"
        payload = {"chat_id": self.chat_id, "text": text, "parse_mode": "HTML"}
        async with aiohttp.ClientSession() as s:
            await s.post(url, json=payload)

    async def send_image(self, image_path, caption):
        url = f"{self.api_url}/sendPhoto"
        data = aiohttp.FormData()
        data.add_field('chat_id', str(self.chat_id))
        data.add_field('photo', open(image_path, 'rb'))
        data.add_field('caption', caption)
        async with aiohttp.ClientSession() as s:
            await s.post(url, data=data)
