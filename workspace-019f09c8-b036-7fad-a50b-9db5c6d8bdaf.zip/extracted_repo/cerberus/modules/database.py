import sqlite3
from datetime import datetime

class Database:
    def __init__(self, db_path="cerberus.db"):
        self.conn = sqlite3.connect(db_path)
        self.cursor = self.conn.cursor()
        self.create_tables()

    def create_tables(self):
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS hosts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ip TEXT UNIQUE,
                vendor TEXT,
                ports TEXT,
                vulns TEXT,
                credentials TEXT,
                last_seen DATETIME
            )
        ''')
        self.conn.commit()

    def add_host(self, ip, vendor, ports, vulns=None, creds=None):
        now = datetime.now().isoformat()
        vulns_str = ",".join(vulns) if vulns else ""
        ports_str = ",".join(map(str, ports))
        
        self.cursor.execute('''
            INSERT OR REPLACE INTO hosts (ip, vendor, ports, vulns, credentials, last_seen)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (ip, vendor, ports_str, vulns_str, creds, now))
        self.conn.commit()

    def get_vulnerable(self):
        self.cursor.execute("SELECT ip, vendor, vulns, credentials FROM hosts WHERE vulns != '' OR credentials IS NOT NULL")
        return self.cursor.fetchall()
