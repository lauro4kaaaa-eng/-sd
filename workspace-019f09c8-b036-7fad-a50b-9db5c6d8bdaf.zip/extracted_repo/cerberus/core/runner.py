import asyncio
import logging
from dataclasses import dataclass
from typing import List

logger = logging.getLogger(__name__)

@dataclass(frozen=True)
class ProcessResult:
    return_code: int
    stdout: str
    stderr: str
    duration: float

class SubprocessRunner:
    @staticmethod
    async def execute(cmd: List[str], timeout: int = 60) -> ProcessResult:
        start_time = asyncio.get_event_loop().time()
        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            try:
                stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout)
                duration = asyncio.get_event_loop().time() - start_time
                return ProcessResult(
                    return_code=proc.returncode if proc.returncode is not None else 0,
                    stdout=stdout.decode(errors="replace").strip(),
                    stderr=stderr.decode(errors="replace").strip(),
                    duration=duration
                )
            except asyncio.TimeoutError:
                try:
                    proc.kill()
                    await proc.wait()
                except ProcessLookupError:
                    pass
                logger.error(f"Process {cmd[0]} timed out after {timeout}s")
                raise
        except Exception as e:
            logger.error(f"Failed to execute {cmd[0]}: {e}")
            raise
