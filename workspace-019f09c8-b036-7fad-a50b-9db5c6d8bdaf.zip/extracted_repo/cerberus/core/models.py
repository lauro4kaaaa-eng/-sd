import uuid
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Dict, Any, Optional, Protocol, runtime_checkable
from datetime import datetime, UTC

class TaskStatus(Enum):
    PENDING = auto()
    RUNNING = auto()
    COMPLETED = auto()
    FAILED = auto()

@dataclass(frozen=True)
class TaskRequest:
    module: str
    target: str
    options: Dict[str, Any] = field(default_factory=dict)
    id: str = field(default_factory=lambda: str(uuid.uuid4()))

@dataclass(frozen=True)
class TaskState:
    status: TaskStatus
    started_at: Optional[datetime] = None
    finished_at: Optional[datetime] = None
    result: Optional[Dict[str, Any]] = None
    error: Optional[str] = None

@runtime_checkable
class IModule(Protocol):
    async def run(self, target: str, options: Dict[str, Any]) -> Dict[str, Any]:
        ...
