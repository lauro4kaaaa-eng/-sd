import asyncio
import importlib
import logging
from datetime import datetime, UTC
from typing import Dict, Any, List, Optional
from cerberus.core.models import TaskRequest, TaskState, TaskStatus, IModule

logger = logging.getLogger(__name__)

class ShutdownSentinel:
    pass

class Orchestrator:
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.queue: asyncio.Queue = asyncio.Queue(maxsize=100)
        self._states: Dict[str, TaskState] = {}
        self._workers: List[asyncio.Task] = []
        self._is_stopping = False

    async def submit(self, module: str, target: str, options: Optional[Dict] = None) -> str:
        req = TaskRequest(module=module, target=target, options=options or {})
        self._states[req.id] = TaskState(status=TaskStatus.PENDING)
        await self.queue.put(req)
        return req.id

    async def _execute_task(self, req: TaskRequest):
        self._states[req.id] = TaskState(status=TaskStatus.RUNNING, started_at=datetime.now(UTC))
        try:
            mod_path = f"cerberus.modules.{req.module}.engine"
            mod = importlib.import_module(mod_path)
            scanner = mod.Scanner(self.config)
            
            if not isinstance(scanner, IModule):
                raise TypeError(f"Module {req.module} violates IModule protocol")

            res_data = await asyncio.wait_for(
                scanner.run(req.target, req.options),
                timeout=self.config.get("task_timeout", 30)
            )
            self._states[req.id] = TaskState(
                status=TaskStatus.COMPLETED,
                result=res_data,
                started_at=self._states[req.id].started_at,
                finished_at=datetime.now(UTC)
            )
        except Exception as e:
            logger.error(f"Task {req.id} failed: {e}")
            self._states[req.id] = TaskState(
                status=TaskStatus.FAILED,
                error=str(e),
                started_at=self._states[req.id].started_at,
                finished_at=datetime.now(UTC)
            )

    async def _worker(self, worker_id: int):
        while True:
            item = await self.queue.get()
            if isinstance(item, ShutdownSentinel):
                self.queue.task_done()
                break
            try:
                await self._execute_task(item)
            finally:
                self.queue.task_done()

    async def start(self, worker_count: int = 2):
        self._workers = [asyncio.create_task(self._worker(i)) for i in range(worker_count)]

    async def stop(self):
        if self._is_stopping:
            return
        self._is_stopping = True
        for _ in self._workers:
            await self.queue.put(ShutdownSentinel())
        await asyncio.gather(*self._workers, return_exceptions=True)

    def get_state(self, task_id: str) -> Optional[TaskState]:
        return self._states.get(task_id)
