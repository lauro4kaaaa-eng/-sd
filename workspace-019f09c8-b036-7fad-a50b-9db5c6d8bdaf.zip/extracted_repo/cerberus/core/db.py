import aiosqlite
import json
import logging
from datetime import datetime, UTC
from typing import Dict, Any, List

logger = logging.getLogger(__name__)

class Database:
    def __init__(self, db_path: str = "cerberus.db"):
        self.db_path = db_path

    async def initialize(self):
        async with aiosqlite.connect(self.db_path) as db:
            # Включаем WAL режим для конкурентных чтений/записи
            await db.execute("PRAGMA journal_mode=WAL")
            await db.execute("PRAGMA synchronous=NORMAL")
            
            await db.execute('''
                CREATE TABLE IF NOT EXISTS loot (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    target TEXT,
                    module TEXT,
                    data TEXT,
                    timestamp DATETIME
                )
            ''')
            await db.commit()
        logger.info(f"Database initialized in WAL mode: {self.db_path}")

    async def save_loot(self, target: str, module: str, data: Dict[str, Any]):
        try:
            async with aiosqlite.connect(self.db_path) as db:
                await db.execute(
                    "INSERT INTO loot (target, module, data, timestamp) VALUES (?, ?, ?, ?)",
                    (target, module, json.dumps(data), datetime.now(UTC).isoformat())
                )
                await db.commit()
        except Exception as e:
            logger.error(f"DB Write Error: {e}")
