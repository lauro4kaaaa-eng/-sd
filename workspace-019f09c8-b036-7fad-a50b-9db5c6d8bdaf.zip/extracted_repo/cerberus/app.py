import asyncio
import logging
import sys
import threading
from cerberus.core.orchestrator import Orchestrator
from cerberus.core.db import Database
from cerberus.ui.visual_ui import start_ui

async def main():
    logging.basicConfig(level=logging.INFO, format='%(asctime)s | %(levelname)s | %(message)s')
    
    db = Database()
    await db.initialize()
    
    orch = Orchestrator({"task_timeout": 60})
    await orch.start(worker_count=10)

    # Запускаем UI в отдельном потоке
    print("[*] Starting Visual Dashboard on http://127.0.0.1:8080")
    threading.Thread(target=start_ui, daemon=True).start()

    target = sys.argv[1] if len(sys.argv) > 1 else "127.0.0.1"
    
    print(f"\n[*] Инициализация полного аудита для: {target}")

    # Сценарий: Recon -> Brute Force
    t_recon = await orch.submit("recon", target)
    await orch.queue.join()
    
    res = orch.get_state(t_recon)
    if res and res.result and res.result.get("open_ports"):
        print(f"[+] Найдено портов: {res.result['open_ports']}. Запускаем Брутфорс...")
        await db.save_loot(target, "recon", res.result)
        
        t_brute = await orch.submit("brute", target)
        await orch.queue.join()
        
        brute_res = orch.get_state(t_brute)
        if brute_res.status.name == "COMPLETED" and brute_res.result.get("status") == "vulnerable":
            print(f"[!!!] УСПЕХ: Подобран пароль: {brute_res.result['valid_creds']}")
            await db.save_loot(target, "brute", brute_res.result)
    else:
        print("[-] Порты закрыты. Цель защищена.")

    print("\n[*] Сканирование завершено. Дашборд доступен на порту 8080.")
    # Держим программу активной, чтобы UI работал
    while True:
        await asyncio.sleep(10)

if __name__ == "__main__":
    import os
    sys.path.append(os.getcwd())
    asyncio.run(main())
