import asyncio
import pytest
import os
from datetime import datetime
from cerberus.core.orchestrator import Orchestrator
from cerberus.core.models import TaskStatus

@pytest.mark.asyncio
async def test_full_lifecycle():
    orch = Orchestrator({"task_timeout": 5})
    await orch.start(worker_count=1)

    # 1. SUCCESS
    t_id = await orch.submit("mock", "127.0.0.1", {"delay": 0.1})
    await orch.queue.join()
    
    state = orch.get_state(t_id)
    assert state.status == TaskStatus.COMPLETED
    assert state.result["mock"] is True

    # 2. FAILURE
    f_id = await orch.submit("mock", "fail", {"delay": 0.1})
    await orch.queue.join()
    
    f_state = orch.get_state(f_id)
    assert f_state.status == TaskStatus.FAILED
    assert "Intentional failure" in f_state.error

    await orch.stop()

@pytest.mark.asyncio
async def test_module_timeout():
    orch = Orchestrator({"task_timeout": 1}) # Жёсткий таймаут
    await orch.start(worker_count=1)
    
    t_id = await orch.submit("mock", "timeout_target", {"delay": 5})
    await orch.queue.join()
    
    state = orch.get_state(t_id)
    assert state.status == TaskStatus.FAILED
    assert "Timeout" in str(state.error) or "timeout" in str(state.error)
    await orch.stop()

@pytest.mark.asyncio
async def test_non_existent_module():
    orch = Orchestrator({})
    await orch.start(worker_count=1)
    
    t_id = await orch.submit("invalid_module", "127.0.0.1")
    await orch.queue.join()
    
    state = orch.get_state(t_id)
    assert state.status == TaskStatus.FAILED
    assert "No module named" in state.error
    await orch.stop()
