#!/bin/bash
set -e

echo "[*] Starting Cerberus v1.0 Services..."

# 1. Запуск Tor (если нужно)
service tor start || systemctl start tor
sleep 2
echo "[+] Tor service is active."

# 2. Запуск PostgreSQL (локально в контейнере)
# Если база во внешнем контейнере, этот шаг можно пропустить
if [ ! -s "/var/lib/pgsql/data/PG_VERSION" ]; then
    postgresql-setup --initdb
fi
sudo -u postgres pg_ctl -D /var/lib/pgsql/data -l /var/lib/pgsql/data/server.log start
sleep 2
echo "[+] PostgreSQL service is active."

# 3. Запуск основного приложения (или ожидание команды)
if [ "$#" -eq 0 ]; then
    # Если команд нет, запускаем интерактивную консоль
    exec python3 cerberus.py
else
    # Если переданы аргументы (например, scan), выполняем их
    exec python3 cerberus.py "$@"
fi
