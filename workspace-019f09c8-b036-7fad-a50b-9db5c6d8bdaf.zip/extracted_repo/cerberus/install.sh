#!/bin/bash
set -e
sudo dnf install -y python3-devel gcc gcc-c++ make nmap masscan libpcap-devel golang tor
go install -v github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest
sudo cp ~/go/bin/nuclei /usr/local/bin/

python3 -m venv venv
source venv/bin/activate
pip install --upgrade pip setuptools wheel
pip install "greenlet>=3.1.1"
pip install -r requirements.txt
playwright install chromium
echo "[+] Cerberus v1.0 Ready."
