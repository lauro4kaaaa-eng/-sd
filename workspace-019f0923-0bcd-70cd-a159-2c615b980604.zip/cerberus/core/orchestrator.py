# Глобальный оркестратор Cerberus
import asyncio
import uuid
from typing import Dict, List
from core.db import Database
from ui.terminal import print_status

class Orchestrator:
    def __init__(self, config):
        self.config = config
        self.db = Database(config['database'])
        self.queue = asyncio.Queue()
        self.workers = []
        self.running = False

    async def add_task(self, module_name: str, target: str, options: Dict = None):
        task_id = str(uuid.uuid4())
        task = {
            "id": task_id,
            "module": module_name,
            "target": target,
            "options": options or {},
            "status": "queued"
        }
        await self.queue.put(task)
        await self.db.log_task(task)
        return task_id

    async def worker(self, worker_id: int):
        print_status(f"Worker-{worker_id} запущен", "info")
        while self.running:
            task = await self.queue.get()
            try:
                print_status(f"Worker-{worker_id} взял задачу: {task['module']} -> {task['target']}", "info")
                # Динамическая загрузка и выполнение модуля
                module = self.load_module(task['module'])
                result = await module.run(task['target'], task['options'])
                await self.db.save_result(task['id'], result)
                print_status(f"Задача {task['id']} завершена успешно", "success")
            except Exception as e:
                print_status(f"Ошибка в задаче {task['id']}: {e}", "error")
            finally:
                self.queue.task_done()

    def load_module(self, name: str):
        # Логика динамического импорта модулей из папки modules/
        import importlib
        mod = importlib.import_module(f"modules.{name}.main")
        return mod.Module(self.config)

    async def start(self, worker_count: int = 5):
        self.running = True
        self.workers = [asyncio.create_task(self.worker(i)) for i in range(worker_count)]
        await self.queue.join()
