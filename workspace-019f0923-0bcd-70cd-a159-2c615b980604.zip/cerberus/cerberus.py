import cmd2
import asyncio
import sys
import yaml
import os
from ui.terminal import print_banner, print_status, Fore
from core.pipeline import execute_red_team_cycle

class CerberusConsole(cmd2.Cmd):
    intro = f"{Fore.CYAN}Cerberus v1.0 [Apex Predator - Dark Node Mode]{Fore.RESET}"
    prompt = f"{Fore.RED}cerberus{Fore.RESET}# "

    def __init__(self):
        super().__init__(allow_cli_args=True)
        # Автоматическое создание папок
        os.makedirs("loot", exist_ok=True)
        os.makedirs("reports", exist_ok=True)
        
        with open("config.yaml", "r") as f:
            self.config = yaml.safe_load(f)
        print_banner()

    scan_parser = cmd2.Cmd2ArgumentParser()
    scan_parser.add_argument('target', help='Цель (IP или Домен)')
    scan_parser.add_argument('--red-team', action='store_true', help='Полный цикл Apex Predator')

    @cmd2.with_argparser(scan_parser)
    def do_scan(self, args):
        """Запуск аудита или Red Team операции"""
        loop = asyncio.get_event_loop()
        print_status(f"Инициализация сканирования для {args.target}...", "info")
        
        if args.red_team:
            print_status("ВКЛЮЧЕН РЕЖИМ RED TEAM (АВТОНОМНЫЙ ЦИКЛ)", "warn")
            loop.run_until_complete(execute_red_team_cycle(args.target, self.config))
        else:
            print_status("Запуск обычного Recon...", "info")
            # Здесь вызов Recon модуля

    def do_exit(self, args):
        return True

if __name__ == '__main__':
    app = CerberusConsole()
    sys.exit(app.cmdloop())
