#!/bin/bash
# Cerberus v1.0 - One-Click Installer for Fedora 42
set -e

echo "[*] Настройка Cerberus v1.0..."

# 1. Зависимости Fedora
sudo dnf install -y python3-devel nmap masscan tor postgresql-devel gcc cargo libX11-devel

# 2. Окружение Python
if [ ! -d "venv" ]; then
    python3 -m venv venv
fi
source venv/bin/activate
pip install -r requirements.txt

# 3. Подготовка папок
mkdir -p loot reports logs

echo "[+] Установка завершена!"
echo "[*] Для запуска используйте:"
echo "    source venv/bin/activate"
echo "    python3 cerberus.py"
